﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Collections;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Text;
using System.Drawing;
using System.Linq;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;
public partial class OnlineGepjarmuRegisztraciosRendszer : System.Web.UI.Page
{
    public string lokacio = "";
    public string alluserid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.IsAuthenticated)
        {
            if (DropDownListVamaru.SelectedValue == "1")
            {
                trvamaru.Visible = false;
                tdBejovo.RowSpan = 4;
                td2.RowSpan = 4;
                RequiredFieldValidator6.Enabled = false;
            }
            SqlDataSource rp = (SqlDataSource)Page.Master.FindControl("Tábla");
            GridView gr = (GridView)Page.Master.FindControl("GridView1");
            gr.Visible = true;
            tdBejovo.RowSpan = 4;
            td2.RowSpan = 4;
            string blab = User.Identity.Name.ToString().ToLower();
            ((Label)Master.FindControl("Label1")).Text = "Online Gépjármű Regisztrációs Rendszer";


            blab = blab.ToLower().Trim();
            if (blab == "sghucontrollinguser" || blab == "rbhmcontrollinguser" || blab == "mcpcontrollinguser")
            {
                GepjarmuTipusa.FilterExpression = "Username='" + blab + "'";
                SqlDataSource5.FilterExpression = "Username='" + blab + "'";
                btnExportExcel.Visible = true;
            }
            else
            {
                btnExportExcel.Visible = false;

                GepjarmuTipusa.FilterExpression = "Username='" + blab + "' or Username='Username'";
                SqlDataSource5.FilterExpression = "Username='" + blab + "' or Username='Username'";
            }








            switch (blab)
            {
                case "mcp":
                    SqlDataSource5.FilterExpression = "Expr1 = 383 OR Expr1 = -1  OR Expr1 = 387 ";
                    lokacio = "OR  userid = '188'  or ";
                    alluserid = "188";
                    rp.FilterExpression = lokacio.Substring(lokacio.Length - 20) + "[Expr1] = '-5' OR [Expr1] = '-4' OR [Expr1] = '-3'";
                    Label7.Text = "Rendellési_Szám;Konténerszám";
                    break;
                case "rbhm":
                    SqlDataSource5.FilterExpression = "Expr1 = 382 OR Expr1 = -1 OR Expr1 = 386 ";
                    lokacio = "AND  userid = '192' or ";
                    alluserid = "192";
                    rp.FilterExpression = lokacio.Substring(lokacio.Length - 20) + "[Expr1] = '-5' OR [Expr1] = '-4' OR [Expr1] = '-3'";
                    break;
                case "ecb":
                    SqlDataSource5.FilterExpression = "Expr1 = 385 OR Expr1 = -1 OR Expr1 = 386 ";
                    lokacio = "AND  userid = '189' or ";
                    alluserid = "189";
                    rp.FilterExpression = lokacio.Substring(lokacio.Length - 20) + "[Expr1] = '-5' OR [Expr1] = '-4' OR [Expr1] = '-3'";
                    break;
                case "tt":
                    SqlDataSource5.FilterExpression = "Expr1 = 379 OR Expr1 = -1 OR Expr1 = 386 ";
                    lokacio = "AND  userid = '190' or ";
                    alluserid = "190";
                    rp.FilterExpression = lokacio.Substring(lokacio.Length - 20) + "[Expr1] = '-5' OR [Expr1] = '-4' OR [Expr1] = '-3'";
                    break;
                case "logicon":
                    SqlDataSource5.FilterExpression = "Expr1 = 381 OR Expr1 = -1 OR Expr1 = 386 ";
                    lokacio = "AND  userid = '191' or ";
                    alluserid = "191";
                    rp.FilterExpression = lokacio.Substring(lokacio.Length - 20) + "[Expr1] = '-5' OR [Expr1] = '-4' OR [Expr1] = '-3'";
                    break;
                default:
                    alluserid = "";

                    rp.FilterExpression = "";
                    lokacio = "";
                    break;
            }
        }
        else
        {
            FormsAuthentication.SignOut();
            Response.Redirect("~/Login.aspx");
        }
    }
    private void BindGrid()
    {
        //using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        //{
        //    using (SqlCommand cmd = new SqlCommand())
        //    {
        //        cmd.CommandText = "SELECT dbo.rendszamok.rendszam, dbo.rendszamok.alvallalkozo, dbo.Kamionkezelo.soforneve, dbo.Kamionkezelo.KÁRTYA, dbo.Kamionkezelo.ertkezettdatum,                        dbo.Kamionkezelo.behivasdatuma, dbo.Kamionkezelo.tavozasdatuma, dbo.Kamionkezelo.rampa, dbo.Kamionkezelo.mithozott, dbo.Kamionkezelo.palettabefele,                          dbo.Kamionkezelo.szalitolevelCMRbefele, dbo.Kamionkezelo.plombaszambefele, dbo.Kamionkezelo.tavozasmodja, dbo.Kamionkezelo.mitvisz,                           dbo.Kamionkezelo.palettaszamkifele, dbo.Kamionkezelo.szalitolevelCMRkifel, dbo.Kamionkezelo.Plombaszamkifel, dbo.Kamionkezelo.[ELLENŐRZÉST VÉGEZTE],                           dbo.Kamionkezelo.VÁMÁRUS, dbo.Kamionkezelo.MEGJEGYZÉS, dbo.Users.Username, dbo.Users.Email FROM            dbo.Kamionkezelo INNER JOIN                          dbo.rendszamok ON dbo.Kamionkezelo.vontatorendszam = dbo.rendszamok.id AND dbo.Kamionkezelo.potkocsirendszam = dbo.rendszamok.id INNER JOIN                          dbo.Users ON dbo.Kamionkezelo.USERID = dbo.Users.UserId LEFT OUTER JOIN                          dbo.Transportes ON dbo.Kamionkezelo.fovalalkozo = dbo.Transportes.transporter_id AND dbo.Kamionkezelo.alvalalkozó = dbo.Transportes.transporter_id AND                           dbo.rendszamok.alvallalkozo = dbo.Transportes.transporter_id                                 ";
        //        cmd.Connection = con;
        //        DataTable dt = new DataTable();
        //        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
        //        {
        //            sda.Fill(dt);
        //            GridView1.DataSource = dt;
        //            GridView1.DataBind();
        //        }
        //    }
        //}
    }
    //protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //    //GridView1.PageIndex = e.NewPageIndex;
    //    this.BindGrid();
    //}
    public string Feltoltes(string query, string insert, string be)
    {
        SqlDataReader dataReader;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@bemenoadat", SqlDbType.VarChar).Value = be;
                con.Open();
                dataReader = command.ExecuteReader();
            }
            if (dataReader.Read())
            {
                if (dataReader[0] != DBNull.Value)
                {
                    return dataReader[0].ToString();
                }
            }
            else if (insert == "")
            {
                return "0";
            }
        }
        string a = insert.Substring(9, insert.Length - 9);
        if (insert.Substring(0, 9) == "azonosito")
        {
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                insert = insert.Substring(9, insert.Length - 9);
                insert = "insert into  dbo.Kamionkezelo(befele,vontatorendszam,lokacio,Azonosito,userid) values(" + insert + ");";
                using (SqlCommand command = new SqlCommand(insert, con))
                {
                    con.Open();
                    command.ExecuteNonQuery();
                    con.Close();
                }
            }
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                a = a.Remove(0, 1);
                insert = "insert into  dbo.Kamionkezelo(befele,vontatorendszam,lokacio,Azonosito,userid) values(0" + a + ");";
                using (SqlCommand command = new SqlCommand(insert, con))
                {
                    con.Open();
                    command.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        else
        {
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(insert, con))
                {
                    command.Parameters.Add("@bemenoadat", SqlDbType.VarChar).Value = be;
                    con.Open();
                    command.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@bemenoadat", SqlDbType.VarChar).Value = be;
                con.Open();
                dataReader = command.ExecuteReader();
            }
            if (dataReader.Read())
            {
                return dataReader[0].ToString();
            }
        }
        return null;
    }
    public string KamionkezeloID;
    int azonosito;
    protected void Button1_Click(object sender, EventArgs e)
    {
        int ures = 0;
        int i = 0;
        if (DropDownListUres.SelectedValue == "2")
        {
            ures = 1;
        }
        else
        {
            ures = 0;
        }
        string query = "";
        int Soforneve = int.Parse(Feltoltes("SELECT UserId FROM dbo.Users WHERE (Nev = @bemenoadat);", "insert into  dbo.Users(Nev) values(@bemenoadat);", TextBoxSoforNeve.Text.Trim()));
        int Utassneve = int.Parse(Feltoltes("SELECT UserId FROM dbo.Users WHERE (Nev = @bemenoadat);", "insert into  dbo.Users(Nev) values(@bemenoadat);", TextBoxUtasNeve.Text.Trim()));
        int vontatorendszam = int.Parse(Feltoltes("SELECT id FROM dbo.rendszamok WHERE (rendszam = @bemenoadat);", "insert into  dbo.rendszamok(rendszam) values(@bemenoadat);", TextBoxVontatoRendszam.Text.Trim().ToLower()));
        int potkocsirendszam = int.Parse(Feltoltes("SELECT id FROM dbo.rendszamok WHERE (rendszam = @bemenoadat);", "insert into  dbo.rendszamok(rendszam) values(@bemenoadat);", TextBoxPotkocsiRendszam.Text.Trim().ToLower()));
        int ellenorzestvegezte = int.Parse(Feltoltes("SELECT UserId FROM dbo.Users WHERE (Nev = @bemenoadat);", "insert into  dbo.Users(Nev) values(@bemenoadat);", TextBoxEllenorzestVegezte.Text.Trim()));
        int userid = int.Parse(Feltoltes("SELECT UserId FROM dbo.Users WHERE (Nev = @bemenoadat);", "insert into  dbo.Users(Nev) values(@bemenoadat);", User.Identity.Name.ToString().Trim()));
        int fovalalkozo;
        int lokacio = 0;
        int irany;
        int gepjarmutipusa;
        gepjarmutipusa = int.Parse(Feltoltes("SELECT ID FROM [dbo].[gepjarmuvekcsoportositasa] WHERE (gepjarmufajtai = @bemenoadat);", "insert into  dbo.gepjarmuvekcsoportositasa(gepjarmufajtai) values(@bemenoadat);", DropDownListGepjarmuTipusa.SelectedItem.Text.Trim()));
      
        if (TextBoxFovalalkozo.Visible == true)
        {
            fovalalkozo = int.Parse(Feltoltes("SELECT ID FROM dbo.Transportes WHERE (transporter_name = @bemenoadat)", "insert into  dbo.Transportes(transporter_name,fovallalkozo) values(@bemenoadat,1);", TextBoxFovalalkozo.Text.Trim()));
        }
        else
        {
            fovalalkozo = int.Parse(DropDownListFovalalkozo.SelectedValue);
        }
        int alvalakozo;
        if (TextBoxAllvalalkozo.Visible == true)
        {
            alvalakozo = int.Parse(Feltoltes("SELECT ID FROM dbo.Transportes WHERE (transporter_name = @bemenoadat)", "insert into  dbo.Transportes(transporter_name,fovallalkozo) values(@bemenoadat,0);", User.Identity.Name.ToString().Trim()));
        }
        else
        {
            alvalakozo = int.Parse(DropDownListAlvallalkozo.SelectedValue);
        }
        if (TextBoxIrany.Text == "Bejövő")
        {
            query = "INSERT INTO [RBHM_LOG-T].[dbo].[Kamionkezelo](vontatorendszam,potkocsirendszam,lokacio,befele,tomege,soforneve,utasneve,datum,behivasdatuma,rampa,fovalalkozo,alvalalkozó,beszallito,szalitolevelCMR,plombaszam,egyebbazonosito,vamaru,vamaruserult,ellenorzestvegezte,ellenorzesmodja,megjeygyzes,Azonosito,ures,elerhetoseg,userid,gepjarmutipusa) VALUES  (@vontatorendszam,@potkocsirendszam,@lokacio,@befele,@tomege,@soforneve,@utasneve,@datum,@behivasdatuma,@rampa,@fovallalkozo,@alvalalkozo,@beszallito,@szalitolevelCMR,@plombaszam,@egyebbazonosito,@vamaru,@vamaruserult,@ellenorzestvegezte,@ellenorzesmodja,@megjegyzes,@Azonosito,@ures,@elerhetoseg,@userid,@gepjarmutipusa)";
            azonosito = int.Parse(Feltoltes("SELECT  TOP (1) PERCENT dbo.Kamionkezelo.Azonosito AS Expr1 FROM dbo.Kamionkezelo INNER JOIN dbo.rendszamok ON dbo.Kamionkezelo.vontatorendszam = dbo.rendszamok.id WHERE (dbo.Kamionkezelo.befele = 1) ORDER BY Expr1 DESC", "", TextBoxVontatoRendszam.Text.Trim())) + 1;
            irany = 1;
        }
        else
        {
            query = "update [RBHM_LOG-T].[dbo].[Kamionkezelo] set potkocsirendszam=@potkocsirendszam, lokacio=@lokacio, befele=@befele, tomege=@tomege, soforneve=@soforneve, utasneve=@utasneve, datum=@datum, behivasdatuma=@behivasdatuma, rampa=@rampa, fovalalkozo=@fovallalkozo, alvalalkozó=@alvalalkozo, beszallito=@beszallito, szalitolevelCMR=@szalitolevelCMR, ures=@ures, elerhetoseg=@elerhetoseg, userid=@userid, gepjarmutipusa=@gepjarmutipusa where [RBHM_LOG-T].[dbo].[Kamionkezelo].Azonosito=@Azonosito and [RBHM_LOG-T].[dbo].[Kamionkezelo].[befele] = 0";
            azonosito = int.Parse(Feltoltes("SELECT  TOP (1) PERCENT dbo.Kamionkezelo.Azonosito AS Expr1 FROM dbo.Kamionkezelo INNER JOIN dbo.rendszamok ON dbo.Kamionkezelo.vontatorendszam = dbo.rendszamok.id WHERE (dbo.Kamionkezelo.befele = 1) ORDER BY Expr1 DESC", "", TextBoxVontatoRendszam.Text.Trim())) + 1;
            azonosito = int.Parse(Feltoltes("SELECT  dbo.Kamionkezelo.Azonosito AS Expr1 FROM dbo.Kamionkezelo INNER JOIN dbo.rendszamok ON dbo.Kamionkezelo.vontatorendszam = dbo.rendszamok.id WHERE (dbo.rendszamok.rendszam = @bemenoadat) AND (dbo.Kamionkezelo.befele = 1) ORDER BY Expr1 DESC", "azonosito1," + vontatorendszam + "," + lokacio + "," + azonosito + "," + alluserid, TextBoxVontatoRendszam.Text.Trim()));
            irany = 0;
        }
        //  az elso Sort feltoltes
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@vontatorendszam", SqlDbType.Int).Value = vontatorendszam;
                command.Parameters.Add("@potkocsirendszam", SqlDbType.Int).Value = potkocsirendszam;
                command.Parameters.Add("@lokacio", SqlDbType.Int).Value = lokacio;
                command.Parameters.Add("@befele", SqlDbType.Bit).Value = irany;
                double num;
                if (double.TryParse(TextBoxTomeg.Text.ToString(), out num))
                {
                    command.Parameters.Add("@tomege", SqlDbType.Int).Value = int.Parse(TextBoxTomeg.Text);
                }
                else
                {
                    command.Parameters.Add("@tomege", SqlDbType.Int).Value = DBNull.Value;
                }
                command.Parameters.Add("@soforneve", SqlDbType.Int).Value = Soforneve;
                command.Parameters.Add("@utasneve", SqlDbType.SmallInt).Value = Utassneve;
                command.Parameters.Add("@datum", SqlDbType.DateTime).Value = DateParse(TextBoxDatum.Text + " " + TextBoxIdopont.Text);
                if (TextBoxBehivasDatum.Text == "" || TextBoxBehivasIdopont.Text == "")
                {
                    command.Parameters.Add("@behivasdatuma", SqlDbType.DateTime).Value = DBNull.Value;
                }
                else
                {
                    if (TextBoxIrany.Text == "Bejövő")
                    {
                        command.Parameters.Add("@behivasdatuma", SqlDbType.DateTime).Value = DateParse(TextBoxBehivasDatum.Text + " " + TextBoxBehivasIdopont.Text);
                    }
                    else
                    {
                        command.Parameters.Add("@behivasdatuma", SqlDbType.DateTime).Value = DBNull.Value;
                    }
                }
                if (TextBoxRampa.Text == "")
                {
                    command.Parameters.Add("@rampa", SqlDbType.Float).Value = DBNull.Value;
                }
                else
                {
                    command.Parameters.Add("@rampa", SqlDbType.Float).Value = float.Parse(TextBoxRampa.Text);
                }
                if (Szallirtmanyozofovallakozo.Text == "Szállítmányozó (Fővállalkozó) Elérhetőség:")
                {
                    command.Parameters.Add("@fovallalkozo", SqlDbType.NChar).Value = DBNull.Value;
                    command.Parameters.Add("@elerhetoseg", SqlDbType.NChar).Value = fovalalkozo.ToString();
                }
                else
                {
                    command.Parameters.Add("@fovallalkozo", SqlDbType.NChar).Value = fovalalkozo.ToString();
                    command.Parameters.Add("@elerhetoseg", SqlDbType.NChar).Value = DBNull.Value;
                }
                if (alvalakozo.ToString() == "" || alvalakozo.ToString() == "-1")
                {
                    command.Parameters.Add("@alvalalkozo", SqlDbType.NChar).Value = DBNull.Value;
                }
                else
                {
                    command.Parameters.Add("@alvalalkozo", SqlDbType.NChar).Value = alvalakozo.ToString();
                }
                if (TextBoxBeszallito.Text == "")
                {
                    command.Parameters.Add("@beszallito", SqlDbType.NChar).Value = DBNull.Value;
                }
                else
                {
                    command.Parameters.Add("@beszallito", SqlDbType.NChar).Value = TextBoxBeszallito.Text.ToString();
                }
                command.Parameters.Add("@hanydarabottszallit", SqlDbType.Int).Value = alvalakozo;
                command.Parameters.Add("@szalitolevelCMR", SqlDbType.VarChar).Value = TextBox7.Text.ToString();
                command.Parameters.Add("@plombaszam", SqlDbType.VarChar).Value = TextBoxPlombaSzam.Text.ToString();
                command.Parameters.Add("@egyebbazonosito", SqlDbType.VarChar).Value = TextBox8.Text.ToString();
                if (DropDownListVamaru.Text == "1")
                {
                    command.Parameters.Add("@vamaru", SqlDbType.Bit).Value = 1;
                }
                else
                {
                    command.Parameters.Add("@vamaru", SqlDbType.Bit).Value = 0;
                }
                if (DropDownListVamaruSerult.SelectedValue == "1")
                {
                    command.Parameters.Add("@vamaruserult", SqlDbType.Bit).Value = 1;
                }
                else
                {
                    command.Parameters.Add("@vamaruserult", SqlDbType.Bit).Value = 0;
                }
                command.Parameters.Add("@gepjarmutipusa", SqlDbType.Int).Value = gepjarmutipusa;
                command.Parameters.Add("@ellenorzestvegezte", SqlDbType.NChar).Value = ellenorzestvegezte;
                command.Parameters.Add("@ellenorzesmodja", SqlDbType.NChar).Value = TextBoxEllenorzesModja.Text;
                command.Parameters.Add("@megjegyzes", SqlDbType.NChar).Value = TextBoxMegjegyzes.Text.ToString();
                command.Parameters.Add("@Azonosito", SqlDbType.Int).Value = azonosito;
                command.Parameters.Add("@ures", SqlDbType.Bit).Value = ures;
                command.Parameters.Add("@userid", SqlDbType.Int).Value = userid;
                con.Open();
                command.ExecuteNonQuery();
                con.Close();
            }
            //a plusz sor feltoltes!
            if (TextBoxIrany.Text == "Bejövő")
            {
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    command.Parameters.Add("@vontatorendszam", SqlDbType.Int).Value = vontatorendszam;
                    command.Parameters.Add("@potkocsirendszam", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@lokacio", SqlDbType.Int).Value = lokacio;
                    command.Parameters.Add("@befele", SqlDbType.Bit).Value = 0;
                    command.Parameters.Add("@tomege", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@soforneve", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@utasneve", SqlDbType.SmallInt).Value = DBNull.Value;
                    command.Parameters.Add("@datum", SqlDbType.DateTime).Value = DBNull.Value;
                    command.Parameters.Add("@behivasdatuma", SqlDbType.DateTime).Value = DBNull.Value;
                    command.Parameters.Add("@rampa", SqlDbType.Float).Value = DBNull.Value;
                    command.Parameters.Add("@fovallalkozo", SqlDbType.NChar).Value = DBNull.Value;
                    command.Parameters.Add("@alvalalkozo", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@beszallito", SqlDbType.NChar).Value = DBNull.Value;
                    command.Parameters.Add("@szalitolevelCMR", SqlDbType.VarChar).Value = DBNull.Value;
                    command.Parameters.Add("@plombaszam", SqlDbType.VarChar).Value = DBNull.Value;
                    command.Parameters.Add("@egyebbazonosito", SqlDbType.VarChar).Value = DBNull.Value;
                    command.Parameters.Add("@vamaru", SqlDbType.Bit).Value = DBNull.Value;
                    command.Parameters.Add("@vamaruserult", SqlDbType.Bit).Value = DBNull.Value;
                    command.Parameters.Add("@ellenorzestvegezte", SqlDbType.NChar).Value = DBNull.Value;
                    command.Parameters.Add("@ellenorzesmodja", SqlDbType.NChar).Value = DBNull.Value;
                    command.Parameters.Add("@megjegyzes", SqlDbType.NChar).Value = DBNull.Value;
                    command.Parameters.Add("@Azonosito", SqlDbType.Int).Value = azonosito;
                    command.Parameters.Add("@ures", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@elerhetoseg", SqlDbType.VarChar).Value = DBNull.Value;
                    command.Parameters.Add("@userid", SqlDbType.Int).Value = DBNull.Value;
                    command.Parameters.Add("@gepjarmutipusa", SqlDbType.Int).Value = DBNull.Value;
                    con.Open();
                    command.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        SqlDataReader dataReader;
        if (ures == 0)
        {
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                query = "SELECT id, befele, lokacio FROM dbo.Kamionkezelo WHERE (befele = 1) AND (lokacio = " + lokacio + ") ORDER BY id DESC";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    con.Open();
                    dataReader = command.ExecuteReader();
                    if (dataReader.Read())
                    {
                        KamionkezeloID = dataReader[0].ToString();
                    }
                }
            }
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                i = 0;
                string[] stringArray = new string[10];
                string[] intArray = new string[10];
                foreach (Control ctrl in PlaceHolder1.Controls)
                {
                    if (ctrl is TextBox)
                    {
                        TextBox actualtextbox1 = (TextBox)ctrl;
                        if (actualtextbox1.Text.ToString() != "")
                        {
                            stringArray[i] = actualtextbox1.Text.ToString();
                            i = i + 1;
                        }
                    }
                }
                i = 0;
                foreach (Control cmb in PlaceHolder2.Controls)
                {
                    if (cmb is DropDownList)
                    {
                        if (cmb.Visible == true)
                        {
                            DropDownList cmbdrop = (DropDownList)cmb;
                            intArray[i] = cmbdrop.SelectedValue.ToString();
                            i = i + 1;
                        }
                    }
                    if (cmb is TextBox)
                    {
                        if (cmb.Visible == true)
                        {
                            TextBox textboxcmbr = (TextBox)cmb;
                            intArray[i] = Feltoltes("SELECT id,megnevezes  FROM [RBHM_LOG-T].[dbo].[mitszallit]   WHERE (megnevezes = @bemenoadat);", "insert into  [RBHM_LOG-T].[dbo].[mitszallit](megnevezes) values(@bemenoadat);", textboxcmbr.Text.Trim());
                            i = i + 1;
                        }
                    }
                }
                i = 0;
                foreach (string item in stringArray)
                {
                    try
                    {
                        int test = int.Parse(intArray[i]);
                        if (test != 0)
                        {
                            query = "INSERT INTO [RBHM_LOG-T].[dbo].[KamionkezeloMennyiseg](KamionkezeloID,hanydarabottszallit,mitszallit) VALUES  (@KamionkezeloID,@hanydarabottszallit,@mitszallit)";
                            using (SqlCommand command = new SqlCommand(query, con))
                            {
                                command.Parameters.Add("@KamionkezeloID", SqlDbType.Int).Value = KamionkezeloID;
                                command.Parameters.Add("@hanydarabottszallit", SqlDbType.Int).Value = stringArray[i];
                                command.Parameters.Add("@mitszallit", SqlDbType.Int).Value = int.Parse(intArray[i]);
                                con.Open();
                                command.ExecuteNonQuery();
                                con.Close();
                            }
                        }
                        i = i + 1;
                    }
                    catch (Exception)
                    {
                        break;
                    }
                }
            }
        }
        GridView gr = (GridView)Page.Master.FindControl("GridView1");
        gr.DataBind();
        Page.Response.Redirect(Page.Request.Url.ToString(), true);
        gr.DataBind();
        string script = "alert(\"Adatok mentése megtörtént!\");";
        ScriptManager.RegisterStartupScript(this, GetType(),
                              "ServerControlScript", script, true);
    }
    public static DateTime DateParse(string date)
    {
        date = date.Trim();
        if (!string.IsNullOrEmpty(date))
            return DateTime.Parse(date, new System.Globalization.CultureInfo("en-GB"));
        return new DateTime();
    }
    protected void rendszamkeresbe(object sender)
    {
        string feltetel = "";
        if (alluserid != "")
        {
            feltetel = "[userid] ='" + alluserid + "' and";
        }
        Label4.Text = "A kamion már szerepel a telphelyen, adatai:";
        TextBox kontroll = (TextBox)sender;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = @"SELECT * FROM dbo.Kamionkezelo_BE INNER JOIN dbo.Kamionkezelo_KI ON dbo.Kamionkezelo_BE.Azonosito = dbo.Kamionkezelo_KI.Azonosito AND dbo.Kamionkezelo_BE.[VONTATÓ RENDSZÁMA] = dbo.Kamionkezelo_KI.[VONTATÓ RENDSZÁMA]  WHERE " + feltetel + "( dbo.Kamionkezelo_BE.[VONTATÓ RENDSZÁMA] = '" + kontroll.Text.ToString() + "') AND (dbo.Kamionkezelo_KI.[Érkezés/Távozás Dátuma] IS NULL) AND (dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] IS NOT NULL) and (dbo.Kamionkezelo_BE.[torolve] IS NULL)  ORDER BY dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] DESC";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                SqlDataReader dataReader;
                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
                    LabelVontatoRendszam.Text = dataReader["VONTATÓ RENDSZÁMA"].ToString();
                    LabelPotkocsiRendszam.Text = dataReader["PÓTKOCSI RENDSZÁMA"].ToString();
                    LabelIrany.Text = "Befelé";
                    LabelSoforneve.Text = dataReader["Soför Neve"].ToString();
                    LabelUtasNeve.Text = dataReader["Utas Neve"].ToString();
                    LabelerkezesDatuma0.Text = dataReader[6].ToString().Substring(0, 10);
                    LabelerkezesIdopontja0.Text = dataReader[6].ToString().Substring(dataReader[6].ToString().Length - 8, 5);
                    Labelrampa.Text = dataReader["RÁMPA"].ToString();
                    LabelTomeg.Text = dataReader[17].ToString();
                    LabelFovalalkozo0.Text = dataReader[8].ToString();
                    LabelAlvalakozo0.Text = dataReader["FUVAROZÓ (Alvállalkozó)"].ToString();
                    //  LabelBeszallito0.Text = dataReader["BESZÁLLÍTÓ"].ToString();
                    CMRSzam.Text = dataReader["SZÁLLÍTÓLEVÉL / CMR"].ToString();
                    PlombaSzam.Text = dataReader["PLOMBA-SZÁM"].ToString();
                    Labelegyebb.Text = dataReader["SZÁLLÍTMÁNY EGYEDI AZONOSÍTÓ"].ToString();
                    LabelVAmjog.Text = dataReader["SZÁLLÍTMÁNY STÁTUSZA (vámáru / nem vámáru)"].ToString();
                    LabelVamSerult.Text = dataReader["VÁMZÁR SÉRÜLT-E (sérült / nem)"].ToString();
                    LabelEllenorzestVegezte.Text = dataReader["Ellenörzést Végezte"].ToString();
                    EllenorzesModjka.Text = dataReader["ELLENŐRZÉS MÓDJA"].ToString();
                    LabelMegjegyzes.Text = dataReader[22].ToString();
                    LabelLokaciokimeno.Text = dataReader["Lokáció"].ToString();
                    LabelLokaciokimeno.Text = dataReader["Lokáció"].ToString();
                    LabelBeszallito0.Text = dataReader["beszallito"].ToString();
                    SqlDataSource9.FilterExpression = "KamionkezeloID =" + dataReader["id"].ToString();
                    GridView2.Visible = true;
                    GridView2.DataBind();
                    return;
                }
                else
                {
                    Label4.Visible = false;
                    adat1.Visible = false;
                    adat2.Visible = false;
                    adat3.Visible = false;
                    adat4.Visible = false;
                    adat5.Visible = false;
                    adat7.Visible = false;
                    adat8.Visible = false;
                    adat9.Visible = false;
                    adat10.Visible = false;
                    adat11.Visible = false;
                    adat13.Visible = false;
                    adat14.Visible = false;
                    adat15.Visible = false;
                    adat16.Visible = false;
                    adat17.Visible = false;
                    adat18.Visible = false;
                    adat20.Visible = false;
                    adat21.Visible = false;
                    adat22.Visible = false;
                    adat22.Visible = false;
                    adat23.Visible = false;
                    adat24.Visible = false;
                    adat25.Visible = false;
                    adat26.Visible = false;
                    adat27.Visible = false;
                    adat28.Visible = false;

                    nev2.Visible = false;
                    nev3.Visible = false;
                    nev4.Visible = false;
                    nev5.Visible = false;
                    nev7.Visible = false;
                    nev8.Visible = false;
                    nev9.Visible = false;
                    nev10.Visible = false;
                    nev11.Visible = false;
                    nev13.Visible = false;
                    nev14.Visible = false;
                    nev15.Visible = false;
                    nev16.Visible = false;
                    nev17.Visible = false;
                    nev18.Visible = false;
                    nev22.Visible = false;
                    nev26.Visible = false;
                    Label4.Visible = false;


                }
            }
        }
    }
    protected void rendszamkereski(object sender)
    {
        string feltetel = "";
        if (alluserid != "")
        {
            feltetel = "[userid] ='" + alluserid + "' and";
        }
        Label4.Text = "Bentlővő kamion adatok:";
        TextBox kontroll = (TextBox)sender;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = @"SELECT * FROM dbo.Kamionkezelo_BE INNER JOIN dbo.Kamionkezelo_KI ON dbo.Kamionkezelo_BE.Azonosito = dbo.Kamionkezelo_KI.Azonosito AND dbo.Kamionkezelo_BE.[VONTATÓ RENDSZÁMA] = dbo.Kamionkezelo_KI.[VONTATÓ RENDSZÁMA]  WHERE " + feltetel + "( dbo.Kamionkezelo_BE.[VONTATÓ RENDSZÁMA] = '" + kontroll.Text.ToString() + "') AND (dbo.Kamionkezelo_KI.[Érkezés/Távozás Dátuma] IS NULL) AND (dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] IS NOT NULL) and (dbo.Kamionkezelo_BE.[torolve] IS NULL)  ORDER BY dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] DESC";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                SqlDataReader dataReader;
                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
                    LabelVontatoRendszam.Text = dataReader["VONTATÓ RENDSZÁMA"].ToString();
                    LabelPotkocsiRendszam.Text = dataReader["PÓTKOCSI RENDSZÁMA"].ToString();
                    LabelIrany.Text = "Befelé";
                    LabelSoforneve.Text = dataReader["Soför Neve"].ToString();
                    LabelUtasNeve.Text = dataReader["Utas Neve"].ToString();
                    LabelerkezesDatuma0.Text = dataReader[6].ToString().Substring(0, 10);
                    LabelerkezesIdopontja0.Text = dataReader[6].ToString().Substring(dataReader[6].ToString().Length - 8, 5);
                    Labelrampa.Text = dataReader["RÁMPA"].ToString();
                    LabelTomeg.Text = dataReader[17].ToString();
                    LabelFovalalkozo0.Text = dataReader[8].ToString();
                    LabelAlvalakozo0.Text = dataReader["FUVAROZÓ (Alvállalkozó)"].ToString();
                    //  LabelBeszallito0.Text = dataReader["BESZÁLLÍTÓ"].ToString();
                    CMRSzam.Text = dataReader["SZÁLLÍTÓLEVÉL / CMR"].ToString();
                    PlombaSzam.Text = dataReader["PLOMBA-SZÁM"].ToString();
                    Labelegyebb.Text = dataReader["SZÁLLÍTMÁNY EGYEDI AZONOSÍTÓ"].ToString();
                    LabelVAmjog.Text = dataReader["SZÁLLÍTMÁNY STÁTUSZA (vámáru / nem vámáru)"].ToString();
                    LabelVamSerult.Text = dataReader["VÁMZÁR SÉRÜLT-E (sérült / nem)"].ToString();
                    LabelEllenorzestVegezte.Text = dataReader["Ellenörzést Végezte"].ToString();
                    EllenorzesModjka.Text = dataReader["ELLENŐRZÉS MÓDJA"].ToString();
                    LabelMegjegyzes.Text = dataReader[22].ToString();
                    LabelLokaciokimeno.Text = dataReader["Lokáció"].ToString();
                    LabelLokaciokimeno.Text = dataReader["Lokáció"].ToString();
                    LabelBeszallito0.Text = dataReader["beszallito"].ToString();
                    SqlDataSource9.FilterExpression = "KamionkezeloID =" + dataReader["id"].ToString();
                    GridView2.Visible = true;
                    GridView2.DataBind();
                    return;
                }
            }
        }
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = @"SELECT * FROM dbo.Kamionkezelo_BE INNER JOIN dbo.Kamionkezelo_KI ON dbo.Kamionkezelo_BE.Azonosito = dbo.Kamionkezelo_KI.Azonosito AND dbo.Kamionkezelo_BE.[VONTATÓ RENDSZÁMA] = dbo.Kamionkezelo_KI.[VONTATÓ RENDSZÁMA] WHERE " + feltetel + "( dbo.Kamionkezelo_BE.[VONTATÓ RENDSZÁMA] = '" + kontroll.Text.ToString() + "') and (dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] IS not NULL) AND (dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] IS not NULL) ORDER BY dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma]";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                SqlDataReader dataReader;
                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
                    LabelVontatoRendszam.Text = "Ez a rendszám már távozott a telephelyről!";
                    LabelPotkocsiRendszam.Text = "";
                    LabelIrany.Text = "";
                    LabelSoforneve.Text = "";
                    LabelUtasNeve.Text = "";
                    LabelerkezesDatuma0.Text = "";
                    LabelerkezesIdopontja0.Text = "";
                    Labelrampa.Text = "";
                    LabelTomeg.Text = "";
                    LabelFovalalkozo0.Text = "";
                    LabelAlvalakozo0.Text = "";
                    CMRSzam.Text = "";
                    PlombaSzam.Text = "";
                    Labelegyebb.Text = "";
                    LabelVAmjog.Text = "";
                    LabelVamSerult.Text = "";
                    LabelEllenorzestVegezte.Text = "";
                    EllenorzesModjka.Text = "";
                    LabelMegjegyzes.Text = "";
                    LabelLokaciokimeno.Text = "";
                    LabelLokaciokimeno.Text = "";
                    LabelBeszallito0.Text = "";
                    return;
                }
                else
                {
                    LabelVontatoRendszam.Text = "Nincs ilyen kamion a telephelyen. Kérlek ellenőrizd a rendszámot!";
                    LabelPotkocsiRendszam.Text = "";
                    LabelIrany.Text = "";
                    LabelSoforneve.Text = "";
                    LabelUtasNeve.Text = "";
                    LabelerkezesDatuma0.Text = "";
                    LabelerkezesIdopontja0.Text = "";
                    Labelrampa.Text = "";
                    LabelTomeg.Text = "";
                    LabelFovalalkozo0.Text = "";
                    LabelAlvalakozo0.Text = "";
                    CMRSzam.Text = "";
                    PlombaSzam.Text = "";
                    Labelegyebb.Text = "";
                    LabelVAmjog.Text = "";
                    LabelVamSerult.Text = "";
                    LabelEllenorzestVegezte.Text = "";
                    EllenorzesModjka.Text = "";
                    LabelMegjegyzes.Text = "";
                    LabelLokaciokimeno.Text = "";
                    LabelLokaciokimeno.Text = "";
                    LabelBeszallito0.Text = "";
                    return;
                }
            }
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBoxDatum.Text = DateTime.Today.ToString("yyyy.MM.dd");
    }
    protected void Button4_Click1(object sender, EventArgs e)
    {
        TextBoxBehivasDatum.Text = DateTime.Today.ToString("yyyy.MM.dd");
    }
    protected void idopont(object sender, EventArgs e)
    {
        TextBoxBehivasIdopont.Text = DateTime.Now.ToString("HH:mm");
    }
    protected void SqlDataSource5_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
    }
    protected void DropDownListIrany_SelectedIndexChanged(object sender, EventArgs e)
    {
        //if (DropDownListIrany.SelectedValue == "2")
        //{
        //    LabelLokacio.Text = "Lokáció(Honnan indul)::";
        //    LabelDatum.Text = "Távozás dátuma:";
        //    LabelIdopont.Text = "Távozás Időpontja:";
        //    trBehivasDatuma.Visible = false;
        //    trBehivasidopontja.Visible = false;
        //    test.RowSpan = 2;
        //    Td1.RowSpan = 2;
        //    LabelCMR.Text = "Szállítólevél / CMR Száma(Befelé):";
        //    LabelPlomba.Text = "Plomba-szám (Kifelé)";
        //    LabelCMR.Text = "Szállítólevél / CMR (Kifelé):";
        //}
        //else
        //{
        //    LabelLokacio.Text = "Lokáció(Hová érkezik):";
        //    LabelIdopont.Text = "Érkezés Időpontja:";
        //    trBehivasDatuma.Visible = true;
        //    trBehivasidopontja.Visible = true;
        //    test.RowSpan = 4;
        //    Td1.RowSpan = 4;
        //    LabelCMR.Text = "Szállítólevél / CMR (Kifelé):";
        //    LabelCMR.Text = "Szállítólevél / CMR Száma(Befelé):";
        //    LabelPlomba.Text = "Plomba-szám (Befelé)";
        //}
    }
    protected void idopont2(object sender, EventArgs e)
    {
        TextBoxIdopont.Text = DateTime.Now.ToString("HH:mm");
    }
    protected void DropDownListVamaru_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownListVamaru.SelectedValue == "1")
        {
            trvamaru.Visible = true;
            tdBejovo.RowSpan = 5;
            td2.RowSpan = 5;
            RequiredFieldValidator6.Enabled = true;
        }
        else
        {
            trvamaru.Visible = false;
            tdBejovo.RowSpan = 4;
            td2.RowSpan = 4;
            RequiredFieldValidator6.Enabled = false;
        }
    }
    protected void DropDownListFovalalkozo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownListFovalalkozo.SelectedValue == "-2")
        {
            DropDownListFovalalkozo.Visible = false;
            TextBoxFovalalkozo.Visible = true;
        }
        if (DropDownListFovalalkozo.SelectedValue == "-3")
        {
            DropDownListFovalalkozo.Visible = false;
            TextBoxFovalalkozo.Visible = true;
            Szallirtmanyozofovallakozo.Text = "Szállítmányozó (Fővállalkozó) Elérhetőség:";
        }
    }
    protected void DropDownListAlvallalkozo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownListAlvallalkozo.SelectedValue == "-2")
        {
            DropDownListAlvallalkozo.Visible = false;
            TextBoxAllvalalkozo.Visible = true;
        }
    }
    protected void Button11_Click1(object sender, EventArgs e)
    {
    }
    private List<string> ControlList
    {
        get
        {
            if (ViewState["controls"] == null)
            {
                ViewState["controls"] = new List<string>();
            }
            return (List<string>)ViewState["controls"];
        }
    }
    private int NextID
    {
        get
        {
            return ControlList.Count + 1;
        }
    }
    protected override void OnPreInit(EventArgs e)
    {
        base.OnPreInit(e);
    }
    protected override void LoadViewState(object savedState)
    {
        //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString);
        //SqlCommand cmd = new SqlCommand("SELECT '- 1' AS Expr1, '  Kérlek válasz egyet!' AS Expr2 UNION ALL SELECT - 2 AS Expr1, ' Egyéb' AS Expr2 UNION ALL SELECT id, megnevezes FROM mitszallit ORDER BY Expr2", con);
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //DataTable dt = new DataTable();
        //da.Fill(dt);
        //base.LoadViewState(savedState);
        //TextBox textBox = PlaceHolder1.FindControl("TextBox1") as TextBox;
        //foreach (string txtID in ControlList)
        //{
        //    TextBox txt = new TextBox();
        //    txt.ID = txtID;
        //    PlaceHolder1.Controls.Add(txt);
        //    PlaceHolder1.Controls.Add(new LiteralControl("<br>"));
        //}
        //foreach (string txtID2 in ControlList)
        //{
        //    TextBox txt2 = new TextBox();
        //    txt2.ID = txtID2 + txtID2 + txtID2 + txtID2;
        //    txt2.Visible = false;
        //    PlaceHolder3.Controls.Add(txt2);
        //    PlaceHolder3.Controls.Add(new LiteralControl("<br>"));
        //}
        //int szam = PlaceHolder1.Controls.Count;
        //szam = szam - 2;
        //foreach (string dlID in ControlList)
        //{
        //    DropDownList dl = new DropDownList();
        //    dl.ID = dlID + dlID;
        //    dl.AutoPostBack = true;
        //    dl.CssClass = "bevitelimezo";
        //    dl.DataTextField = "Expr2";
        //    dl.DataValueField = "Expr1";
        //    // dl.SelectedIndex =
        //    dl.DataSource = dt;
        //    dl.SelectedIndexChanged += new EventHandler(Button11_Click);
        //    dl.DataBind();
        //    PlaceHolder2.Controls.Add(dl);
        //    PlaceHolder2.Controls.Add(new LiteralControl("<br>"));
        //}
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        //DropDownList cmb = (DropDownList)sender;
        //string selectedIndex = cmb.SelectedValue;
        //string tex = cmb.ID;
        //if (selectedIndex == "-2")
        //{
        //    TextBox textBox = PlaceHolder2.FindControl(cmb.ID + cmb.ID) as TextBox;
        //    textBox.Visible = true;
        //    cmb.Visible = false;
        //}
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        GridView gr = (GridView)Page.Master.FindControl("GridView1");
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
        "attachment;filename=GridViewExport.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        gr.AllowPaging = false;
        // GridView1.DataBind();
        //Change the Header Row back to whiteSystem.Drawing.Color.
        //  GridView1.HeaderRow.Style.Add("background-color", "#FFFFFF");
        //Apply style to Individual Cells
        //GridView1.HeaderRow.Cells[0].Style.Add("background-color", "green");
        //GridView1.HeaderRow.Cells[1].Style.Add("background-color", "green");
        //GridView1.HeaderRow.Cells[2].Style.Add("background-color", "green");
        //GridView1.HeaderRow.Cells[3].Style.Add("background-color", "green");
        for (int i = 0; i < gr.Rows.Count; i++)
        {
            GridViewRow row = gr.Rows[i];
            //Apply text style to each Row
            row.Attributes.Add("class", "textmode");
            //Apply style to Individual Cells of Alternating Row
            if (i % 2 != 0)
            {
                row.Cells[0].Style.Add("background-color", "#C2D69B");
                row.Cells[1].Style.Add("background-color", "#C2D69B");
                row.Cells[2].Style.Add("background-color", "#C2D69B");
                row.Cells[3].Style.Add("background-color", "#C2D69B");
            }
        }
        gr.RenderControl(hw);
        //style to format numbers to string
        string style = @"<style> .textmode { mso-number-format:\@; } </style>";
        Response.Write(style);
        Response.Output.Write(sw.ToString());
        Response.Flush();
        Response.End();
        //DataSourceSelectArguments args = new DataSourceSelectArguments();
        //DataView view = (DataView)Tábla.Select(args);
        //using (DataTable dt = view.ToTable())
        //{
        //    var csv = new StringBuilder();
        //    for (int i = 0; i < dt.Columns.Count; i++)
        //    {
        //        csv.Append(dt.Columns[i].ColumnName);
        //        csv.Append(i == dt.Columns.Count - 1 ? "\n" : ";");
        //    }
        //    foreach (DataRow row in dt.Rows)
        //    {
        //        for (int i = 0; i < dt.Columns.Count; i++)
        //        {
        //            csv.Append(row[i].ToString());
        //            csv.Append(i == dt.Columns.Count - 1 ? "\n" : ";");
        //        }
        //    }
        //    //Download the CSV file.
        //    Response.Clear();
        //    Response.Buffer = true;
        //    Response.AddHeader("content-disposition", "attachment;filename=SqlExport.csv");
        //    Response.Charset = "";
        //    Response.ContentType = "application/text";
        //    Response.Output.Write(csv);
        //    Response.Flush();
        //    Response.End();
        //}
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }
    protected void ButtonBefele_Click(object sender, EventArgs e)
    {
        Label3.Text = "Érkezés módja:";
        LabelFuvar.Text = "Beszállító:";
        rampa1.Visible = true;
        Fuvaradati.RowSpan = 4;
        Fuvaradati2.RowSpan = 4;
        nev2.Visible = false;
        nev3.Visible = false;
        nev4.Visible = false;
        nev5.Visible = false;
        nev7.Visible = false;
        nev8.Visible = false;
        nev9.Visible = false;
        nev10.Visible = false;
        nev11.Visible = false;
        nev13.Visible = false;
        nev14.Visible = false;
        nev15.Visible = false;
        nev16.Visible = false;
        nev17.Visible = false;
        nev18.Visible = false;
        nev22.Visible = false;
        nev26.Visible = false;
        Label4.Visible = false;
        adat1.Visible = false;
        adat2.Visible = false;
        adat3.Visible = false;
        adat4.Visible = false;
        adat5.Visible = false;
        adat7.Visible = false;
        adat8.Visible = false;
        adat9.Visible = false;
        adat10.Visible = false;
        adat11.Visible = false;
        adat13.Visible = false;
        adat14.Visible = false;
        adat15.Visible = false;
        adat16.Visible = false;
        adat17.Visible = false;
        adat18.Visible = false;
        adat20.Visible = false;
        adat21.Visible = false;
        adat22.Visible = false;
        adat23.Visible = false;
        adat24.Visible = false;
        adat25.Visible = false;
        adat26.Visible = false;
        adat27.Visible = false;
        adat28.Visible = false;
        adat29.Visible = false;
        adat30.Visible = false;
        adat31.Visible = false;
        adat32.Visible = false;
        adat33.Visible = false;
        adat34.Visible = false;
        adat35.Visible = false;
        adat36.Visible = false;
        Button4.Visible = true;
        LabelLokacio.Text = "Lokáció (Hová érkezik):";
        LabelIdopont.Text = "Érkezés Időpontja:";
        trBehivasDatuma.Visible = true;
        trBehivasidopontja.Visible = true;
        test.RowSpan = 4;
        Td1.RowSpan = 4;
        LabelCMR.Text = "Szállítólevél / CMR:";
        LabelCMR.Text = "Szállítólevél / CMR Száma:";
        LabelPlomba.Text = "Plomba-szám";
        System.Web.UI.HtmlControls.HtmlGenericControl MasterBody = (System.Web.UI.HtmlControls.HtmlGenericControl)Master.FindControl("MasterBody");
        MasterBody.Attributes.Add("style", "background-color: #fce4d6");
        UpdatePanel2.Visible = true;
        Button1.Visible = true;
        TextBoxIrany.Text = "Bejövő";
        Fejresz.Text = "Bejövő:";
    }
    protected void ButtonKifele_Click(object sender, EventArgs e)
    {
        Label3.Text = "Távozás módja:";
        LabelFuvar.Text = "Címzett:";
        rampa1.Visible = false;
        Fuvaradati.RowSpan = 3;
        Fuvaradati2.RowSpan = 3;
        Label4.Visible = false;
        adat1.Visible = false;
        adat2.Visible = false;
        adat3.Visible = false;
        adat4.Visible = false;
        adat5.Visible = false;
        adat7.Visible = false;
        adat8.Visible = false;
        adat9.Visible = false;
        adat10.Visible = false;
        adat11.Visible = false;
        adat13.Visible = false;
        adat14.Visible = false;
        adat15.Visible = false;
        adat16.Visible = false;
        adat17.Visible = false;
        adat18.Visible = false;
        adat20.Visible = false;
        adat21.Visible = false;
        adat22.Visible = false;
        adat23.Visible = false;
        adat24.Visible = false;
        adat25.Visible = false;
        adat26.Visible = false;
        adat27.Visible = false;
        adat28.Visible = false;
        Button4.Visible = true;
        System.Web.UI.HtmlControls.HtmlGenericControl MasterBody = (System.Web.UI.HtmlControls.HtmlGenericControl)Master.FindControl("MasterBody");
        MasterBody.Attributes.Add("style", "background-color: #a3d89c");
        UpdatePanel2.Visible = true;
        Button1.Visible = true;
        Fejresz.Text = "Kimenő:";
        TextBoxIrany.Text = "Kimenő";
        LabelLokacio.Text = "Lokáció(Honnan indul)::";
        LabelDatum.Text = "Távozás dátuma:";
        LabelIdopont.Text = "Távozás Időpontja:";
        trBehivasDatuma.Visible = false;
        trBehivasidopontja.Visible = false;
        test.RowSpan = 2;
        Td1.RowSpan = 2;
        LabelPlomba.Text = "Plomba-szám (Kifelé)";
        LabelCMR.Text = "Szállítólevél / CMR (Kifelé):";
    }
    protected void TextBoxVontatoRendszam_TextChanged(object sender, EventArgs e)
    {
        TextBoxVontatoRendszam.Text = TextBoxVontatoRendszam.Text.ToString().ToUpper();
        Label4.Visible = true;
        adat1.Visible = true;
        adat2.Visible = true;
        adat3.Visible = true;
        adat4.Visible = true;
        adat5.Visible = true;
        adat7.Visible = true;
        adat8.Visible = true;
        adat9.Visible = true;
        adat10.Visible = true;
        adat11.Visible = true;
        adat13.Visible = true;
        adat14.Visible = true;
        //  adat15.Visible = true;
        adat16.Visible = true;
        adat17.Visible = true;
        adat18.Visible = true;
        adat20.Visible = true;
        adat21.Visible = true;
        adat22.Visible = true;
        adat22.Visible = true;
        adat23.Visible = true;
        adat24.Visible = true;
        adat25.Visible = true;
        adat26.Visible = true;
        adat27.Visible = true;
        adat28.Visible = true;
        nev2.Visible = true;
        nev3.Visible = true;
        nev4.Visible = true;
        nev5.Visible = true;
        nev7.Visible = true;
        nev8.Visible = true;
        nev9.Visible = true;
        nev10.Visible = true;
        nev11.Visible = true;
        nev13.Visible = true;
        nev14.Visible = true;
        nev15.Visible = true;
        nev16.Visible = true;
        nev17.Visible = true;
        nev18.Visible = true;
        nev26.Visible = true;
        adat29.Visible = true;
        adat30.Visible = true;
        adat31.Visible = true;
        adat32.Visible = true;
        adat33.Visible = true;
        adat34.Visible = true;
        adat35.Visible = true;
        adat36.Visible = true;
        if (TextBoxIrany.Text == "Kimenő")
        {
            rendszamkereski(sender);
        }
        if (TextBoxIrany.Text == "Bejövő")
        {
            rendszamkeresbe(sender);
        }
        if (TextBoxVontatoRendszam.Text == "")
        {
            Label4.Visible = false;
            adat1.Visible = false;
            adat2.Visible = false;
            adat3.Visible = false;
            adat4.Visible = false;
            adat5.Visible = false;
            adat7.Visible = false;
            adat8.Visible = false;
            adat9.Visible = false;
            adat10.Visible = false;
            adat11.Visible = false;
            adat13.Visible = false;
            adat14.Visible = false;
            adat15.Visible = false;
            adat16.Visible = false;
            adat17.Visible = false;
            adat18.Visible = false;
            adat20.Visible = false;
            adat21.Visible = false;
            adat22.Visible = false;
            adat22.Visible = false;
            adat23.Visible = false;
            adat24.Visible = false;
            adat25.Visible = false;
            adat26.Visible = false;
            adat27.Visible = false;
            adat28.Visible = false;

            nev2.Visible = false;
            nev3.Visible = false;
            nev4.Visible = false;
            nev5.Visible = false;
            nev7.Visible = false;
            nev8.Visible = false;
            nev9.Visible = false;
            nev10.Visible = false;
            nev11.Visible = false;
            nev13.Visible = false;
            nev14.Visible = false;
            nev15.Visible = false;
            nev16.Visible = false;
            nev17.Visible = false;
            nev18.Visible = false;
            nev22.Visible = false;
            nev26.Visible = false;
            adat29.Visible = false;
            adat30.Visible = false;
            adat31.Visible = false;
            adat32.Visible = false;
            adat33.Visible = false;
            adat34.Visible = false;
            adat35.Visible = false;
            adat36.Visible = false;


            Label4.Visible = false;
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
    }
    protected void torlogomb_Click1(object sender, EventArgs e)
    {
    }
    protected void Button3_Click1(object sender, EventArgs e)
    {
        foreach (Control cnt in PlaceHolder1.Controls)
        {
            if (cnt is TextBox)
            {
                TextBox actualtextbox1 = (TextBox)cnt;
                if (actualtextbox1.Visible == true)
                {
                    if (!Regex.IsMatch(actualtextbox1.Text.ToString().Trim(), @"^\d+$"))
                    {
                        LabelHiba.Text = "Csak szám lehet!";
                        return;
                    }
                    else
                    {
                        LabelHiba.Text = "";
                    }
                }
            }
        }
        foreach (Control cnt in PlaceHolder2.Controls)
        {
            if (cnt is DropDownList)
            {
                DropDownList actualtextbox1 = (DropDownList)cnt;
                if (actualtextbox1.Visible == true)
                {
                    if (actualtextbox1.SelectedIndex == 0)
                    {
                        LabelHiba.Text = "Kérlek válassz egyet a legördülőlistából.";
                        return;
                    }
                    else
                    {
                        LabelHiba.Text = "";
                    }
                }
            }
        }
        int k = 0;
        int proba = 0;
        foreach (Control cnt in PlaceHolder1.Controls)
        {
            if (cnt is TextBox)
            {
                k = k + 1;
                TextBox actualtextbox = (TextBox)cnt;
                if (actualtextbox.Visible == false)
                {
                    actualtextbox.Visible = true;
                    foreach (Control cnt2 in PlaceHolder2.Controls)
                    {
                        if (cnt2 is DropDownList)
                        {
                            proba = proba + 1;
                            if (proba == k)
                            {
                                DropDownList actualdbd = (DropDownList)cnt2;
                                if (actualdbd.Visible == false)
                                {
                                    actualdbd.Visible = true;
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    protected void DropDownList11_SelectedIndexChanged(object sender, EventArgs e)
    {
        int k = 0;
        int proba = 0;
        DropDownList actualdbd = (DropDownList)sender;
        if (actualdbd.SelectedIndex == 1)
        {
            actualdbd.Visible = false;
            foreach (Control cnt2 in PlaceHolder1.Controls)
            {
                if (cnt2 is TextBox)
                {
                    TextBox actualdbd2 = (TextBox)cnt2;
                    if (actualdbd2.Visible == true)
                    {
                        k = k + 1;
                    }
                }
            }
            foreach (Control cnt2 in PlaceHolder2.Controls)
            {
                if (cnt2 is TextBox)
                {
                    proba = proba + 1;
                    if (k == proba)
                    {
                        TextBox actualdbd2 = (TextBox)cnt2;
                        if (actualdbd2.Visible == false)
                        {
                            actualdbd2.Visible = true;
                            return;
                        }
                    }
                }
            }
        }
    }
    protected void TextBoxPotkocsiRendszam_TextChanged(object sender, EventArgs e)
    {
        TextBoxPotkocsiRendszam.Text = TextBoxPotkocsiRendszam.Text.ToString().ToUpper();
        //Label1.Visible = true;
        //potadat1.Visible = true;
        //Potadat2.Visible = true;
        //Potadatd3.Visible = true;
        //Potadat4.Visible = true;
        //PotAdat5.Visible = true;
        //PotAdat7.Visible = true;
        //Potadat8.Visible = true;
        //Potadat9.Visible = true;
        //PotAdat10.Visible = true;
        //PotAdat11.Visible = true;
        //PotAdat13.Visible = true;
        //Potadat14.Visible = true;
        //PotAdat15.Visible = true;
        //PotAdat16.Visible = true;
        //PotAdat17.Visible = true;
        //PotAdat18.Visible = true;
        //PotAdat20.Visible = true;
        //Potadat21.Visible = true;
        //Potadat22.Visible = true;
        //Potadat22.Visible = true;
        //PotAdat23.Visible = true;
        //Potadat24.Visible = true;
        //Potadat25.Visible = true;
        //Potadat26.Visible = true;
        //Potadat27.Visible = true;
        //PotAdat28.Visible = true;
        //if (TextBoxIrany.Text == "Kimenő")
        //{
        //    potkocsirendszamkereski(sender);
        //}
        //if (TextBoxIrany.Text == "Bejövő")
        //{
        //    potkocsirendszamkeresbe(sender);
        //}
        //if (TextBoxPotkocsiRendszam.Text == "")
        //{
        //    Label1.Visible = false;
        //    potadat1.Visible = false;
        //    Potadat2.Visible = false;
        //    Potadatd3.Visible = false;
        //    Potadat4.Visible = false;
        //    PotAdat5.Visible = false;
        //    PotAdat7.Visible = false;
        //    Potadat8.Visible = false;
        //    Potadat9.Visible = false;
        //    PotAdat10.Visible = false;
        //    PotAdat11.Visible = false;
        //    PotAdat13.Visible = false;
        //    Potadat14.Visible = false;
        //    PotAdat15.Visible = false;
        //    PotAdat16.Visible = false;
        //    PotAdat17.Visible = false;
        //    PotAdat18.Visible = false;
        //    PotAdat20.Visible = false;
        //    Potadat21.Visible = false;
        //    Potadat22.Visible = false;
        //    Potadat22.Visible = false;
        //    PotAdat23.Visible = false;
        //    Potadat24.Visible = false;
        //    Potadat25.Visible = false;
        //    Potadat26.Visible = false;
        //    Potadat27.Visible = false;
        //    PotAdat28.Visible = false;
        //}
    }
    protected void potkocsirendszamkeresbe(object sender)
    {
        string feltetel = "";
        if (alluserid != "")
        {
            feltetel = "[userid] ='" + alluserid + "' and";
        }
        Label4.Text = "A kamion már szerepel a telphelyen, adatai:";
        TextBox kontroll = (TextBox)sender;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = @"SELECT * FROM dbo.Kamionkezelo_BE INNER JOIN dbo.Kamionkezelo_KI ON dbo.Kamionkezelo_BE.Azonosito = dbo.Kamionkezelo_KI.Azonosito AND dbo.Kamionkezelo_BE.[PÓTKOCSI RENDSZÁMA] = dbo.Kamionkezelo_KI.[PÓTKOCSI RENDSZÁMA]  WHERE " + feltetel + "( dbo.Kamionkezelo_BE.[PÓTKOCSI RENDSZÁMA] = '" + kontroll.Text.ToString() + "') AND (dbo.Kamionkezelo_KI.[Érkezés/Távozás Dátuma] IS NULL) AND (dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] IS NOT NULL) and (dbo.Kamionkezelo_BE.[torolve] IS NULL)  ORDER BY dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] DESC";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                SqlDataReader dataReader;
                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
                    LabelPotVontatoRendszam.Text = dataReader["VONTATÓ RENDSZÁMA"].ToString();
                    LabelPotkocsiRendszam.Text = dataReader["PÓTKOCSI RENDSZÁMA"].ToString();
                    LabelPotIrany.Text = "Befelé";
                    LabelPotSoforneve.Text = dataReader["Soför Neve"].ToString();
                    LabelPotUtasNeve.Text = dataReader["Utas Neve"].ToString();
                    LabelPoterkezesDatuma0.Text = dataReader[6].ToString().Substring(0, 10);
                    LabelPoterkezesIdopontja0.Text = dataReader[6].ToString().Substring(dataReader[6].ToString().Length - 8, 5);
                    LabelPotrampa.Text = dataReader["RÁMPA"].ToString();
                    LabelPotTomeg.Text = dataReader[17].ToString();
                    LabelPotFovalalkozo0.Text = dataReader[8].ToString();
                    LabelPotAlvalakozo0.Text = dataReader["FUVAROZÓ (Alvállalkozó)"].ToString();
                    //  LabelBeszallito0.Text = dataReader["BESZÁLLÍTÓ"].ToString();
                    LabelPotCMRSzam.Text = dataReader["SZÁLLÍTÓLEVÉL / CMR"].ToString();
                    LabelPotPlombaSzam.Text = dataReader["PLOMBA-SZÁM"].ToString();
                    LabelPotEGyebb.Text = dataReader["SZÁLLÍTMÁNY EGYEDI AZONOSÍTÓ"].ToString();
                    LabelPotVAmjog.Text = dataReader["SZÁLLÍTMÁNY STÁTUSZA (vámáru / nem vámáru)"].ToString();
                    LabelPotVamSerult.Text = dataReader["VÁMZÁR SÉRÜLT-E (sérült / nem)"].ToString();
                    LabelPotEllenorzestVegezte.Text = dataReader["Ellenörzést Végezte"].ToString();
                    LabelPotEllenorzesModjka.Text = dataReader["ELLENŐRZÉS MÓDJA"].ToString();
                    LabelPotMegjegyzes.Text = dataReader[22].ToString();
                    LabelPotLokaciokimeno.Text = dataReader["Lokáció"].ToString();
                    LabelPotLokaciokimeno.Text = dataReader["Lokáció"].ToString();
                    LabelPotBesszalito.Text = dataReader["beszallito"].ToString();
                    SqlDataSource9.FilterExpression = "KamionkezeloID =" + dataReader["id"].ToString();
                    GridView3.Visible = true;
                    GridView3.DataBind();
                    return;
                }
                else
                {
                    Label1.Visible = false;
                    potadat1.Visible = false;
                    Potadat2.Visible = false;
                    Potadatd3.Visible = false;
                    Potadat4.Visible = false;
                    PotAdat5.Visible = false;
                    PotAdat7.Visible = false;
                    Potadat8.Visible = false;
                    Potadat9.Visible = false;
                    PotAdat10.Visible = false;
                    PotAdat11.Visible = false;
                    PotAdat13.Visible = false;
                    Potadat14.Visible = false;
                    PotAdat15.Visible = false;
                    PotAdat16.Visible = false;
                    PotAdat17.Visible = false;
                    PotAdat18.Visible = false;
                    PotAdat20.Visible = false;
                    Potadat21.Visible = false;
                    Potadat22.Visible = false;
                    Potadat22.Visible = false;
                    PotAdat23.Visible = false;
                    Potadat24.Visible = false;
                    Potadat25.Visible = false;
                    Potadat26.Visible = false;
                    Potadat27.Visible = false;
                    PotAdat28.Visible = false;



















                }
            }
        }
    }
    protected void potkocsirendszamkereski(object sender)
    {
        string feltetel = "";
        if (alluserid != "")
        {
            feltetel = "[userid] ='" + alluserid + "' and";
        }
        Label4.Text = "Bentlővő kamion adatok:";
        TextBox kontroll = (TextBox)sender;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = @"SELECT * FROM dbo.Kamionkezelo_BE INNER JOIN dbo.Kamionkezelo_KI ON dbo.Kamionkezelo_BE.Azonosito = dbo.Kamionkezelo_KI.Azonosito WHERE " + feltetel + "( dbo.Kamionkezelo_BE.[PÓTKOCSI RENDSZÁMA] = '" + kontroll.Text.ToString() + "') AND (dbo.Kamionkezelo_KI.[Érkezés/Távozás Dátuma] IS NULL) AND (dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] IS NOT NULL) and (dbo.Kamionkezelo_BE.[torolve] IS NULL)  ORDER BY dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] DESC";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                SqlDataReader dataReader;
                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
                    LabelPotVontatoRendszam.Text = dataReader["VONTATÓ RENDSZÁMA"].ToString();
                    LabelPotPotkocsiRendszam.Text = dataReader["PÓTKOCSI RENDSZÁMA"].ToString();
                    LabelPotIrany.Text = "Befelé";
                    LabelPotSoforneve.Text = dataReader["Soför Neve"].ToString();
                    LabelPotUtasNeve.Text = dataReader["Utas Neve"].ToString();
                    LabelPoterkezesDatuma0.Text = dataReader[6].ToString().Substring(0, 10);
                    LabelPoterkezesIdopontja0.Text = dataReader[6].ToString().Substring(dataReader[6].ToString().Length - 8, 5);
                    LabelPotrampa.Text = dataReader["RÁMPA"].ToString();
                    LabelPotTomeg.Text = dataReader[17].ToString();
                    LabelPotFovalalkozo0.Text = dataReader[8].ToString();
                    LabelPotAlvalakozo0.Text = dataReader["FUVAROZÓ (Alvállalkozó)"].ToString();
                    //  LabelBeszallito0.Text = dataReader["BESZÁLLÍTÓ"].ToString();
                    LabelPotCMRSzam.Text = dataReader["SZÁLLÍTÓLEVÉL / CMR"].ToString();
                    LabelPotPlombaSzam.Text = dataReader["PLOMBA-SZÁM"].ToString();
                    LabelPotEGyebb.Text = dataReader["SZÁLLÍTMÁNY EGYEDI AZONOSÍTÓ"].ToString();
                    LabelPotVAmjog.Text = dataReader["SZÁLLÍTMÁNY STÁTUSZA (vámáru / nem vámáru)"].ToString();
                    LabelPotVamSerult.Text = dataReader["VÁMZÁR SÉRÜLT-E (sérült / nem)"].ToString();
                    LabelPotEllenorzestVegezte.Text = dataReader["Ellenörzést Végezte"].ToString();
                    EllenorzesModjka.Text = dataReader["ELLENŐRZÉS MÓDJA"].ToString();
                    LabelMegjegyzes.Text = dataReader[22].ToString();
                    LabelLokaciokimeno.Text = dataReader["Lokáció"].ToString();
                    LabelLokaciokimeno.Text = dataReader["Lokáció"].ToString();
                    LabelPotBesszalito.Text = dataReader["beszallito"].ToString();
                    SqlDataSource9.FilterExpression = "KamionkezeloID =" + dataReader["id"].ToString();
                    GridView3.Visible = true;
                    GridView3.DataBind();
                    return;
                }
            }
        }
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = @"SELECT * FROM dbo.Kamionkezelo_BE INNER JOIN dbo.Kamionkezelo_KI ON dbo.Kamionkezelo_BE.Azonosito = dbo.Kamionkezelo_KI.Azonosito AND dbo.Kamionkezelo_BE.[VONTATÓ RENDSZÁMA] = dbo.Kamionkezelo_KI.[VONTATÓ RENDSZÁMA] WHERE " + feltetel + "( dbo.Kamionkezelo_BE.[VONTATÓ RENDSZÁMA] = '" + kontroll.Text.ToString() + "') and (dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] IS not NULL) AND (dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma] IS not NULL) ORDER BY dbo.Kamionkezelo_BE.[Érkezés/Távozás Dátuma]";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                SqlDataReader dataReader;
                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
                    LabelPotVontatoRendszam.Text = "Ez a rendszám már távozott a telephelyről!";
                    LabelPotPotkocsiRendszam.Text = "";
                    LabelPotIrany.Text = "";
                    LabelPotSoforneve.Text = "";
                    LabelPotUtasNeve.Text = "";
                    LabelPoterkezesDatuma0.Text = "";
                    LabelPoterkezesIdopontja0.Text = "";
                    LabelPotrampa.Text = "";
                    LabelPotTomeg.Text = "";
                    LabelPotFovalalkozo0.Text = "";
                    LabelPotAlvalakozo0.Text = "";
                    LabelPotCMRSzam.Text = "";
                    LabelPotPlombaSzam.Text = "";
                    LabelPotEGyebb.Text = "";
                    LabelPotVAmjog.Text = "";
                    LabelPotVamSerult.Text = "";
                    LabelPotEllenorzestVegezte.Text = "";
                    LabelPotEllenorzesModjka.Text = "";
                    LabelPotMegjegyzes.Text = "";
                    LabelPotLokaciokimeno.Text = "";
                    LabelPotLokaciokimeno.Text = "";
                    LabelPotBesszalito.Text = "";
                    return;
                }
                else
                {
                    LabelPotVontatoRendszam.Text = "Nincs ilyen kamion a telephelyen. Kérlek ellenőrizd a rendszámot!";
                    LabelPotPotkocsiRendszam.Text = "";
                    LabelPotIrany.Text = "";
                    LabelPotSoforneve.Text = "";
                    LabelPotUtasNeve.Text = "";
                    LabelPoterkezesDatuma0.Text = "";
                    LabelPoterkezesIdopontja0.Text = "";
                    LabelPotrampa.Text = "";
                    LabelPotTomeg.Text = "";
                    LabelPotFovalalkozo0.Text = "";
                    LabelPotAlvalakozo0.Text = "";
                    LabelPotCMRSzam.Text = "";
                    LabelPotPlombaSzam.Text = "";
                    LabelPotEGyebb.Text = "";
                    LabelPotVAmjog.Text = "";
                    LabelPotVamSerult.Text = "";
                    LabelPotEllenorzestVegezte.Text = "";
                    LabelPotEllenorzesModjka.Text = "";
                    LabelPotMegjegyzes.Text = "";
                    LabelPotLokaciokimeno.Text = "";
                    LabelPotLokaciokimeno.Text = "";
                    LabelPotBesszalito.Text = "";
                    return;
                }
            }
        }
    }
    protected void DropDownListUres_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownListUres.SelectedValue == "2")
        {
            mitszallit.Visible = true;
        }
        else
        {
            mitszallit.Visible = false;
        }
    }
    protected void DropDownListUres_TextChanged(object sender, EventArgs e)
    {
        if (DropDownListUres.Text == "2")
        {
            szal1.RowSpan = 3;
            szal2.RowSpan = 3;
            szaad2sor.Visible = true;
            szal3.Visible = true;
        }
        else
        {
            szal1.RowSpan = 1;
            szal2.RowSpan = 1;
            szaad2sor.Visible = false;
            szal3.Visible = false;
        }
    }

}
