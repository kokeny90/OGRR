﻿using System.Net.Mail;
using System.Net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net.Mail;

using System.Runtime.InteropServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

using Outlook = Microsoft.Office.Interop.Outlook;
using System.Diagnostics;

public partial class order : System.Web.UI.Page
{

    [DllImport("MAPI32.DLL", CharSet = CharSet.Ansi)]
    private static extern int MAPIDeleteMail(IntPtr session, IntPtr winhandle,
                                          string id, int flags, int reserved);

    string[] collections;

    protected void Page_Load(object sender, EventArgs e)
    {


    


        if (!this.Page.User.Identity.IsAuthenticated)
        {
            FormsAuthentication.RedirectToLoginPage();
        }
        //  using (System.Security.Principal.WindowsIdentity wi = System.Security.Principal.WindowsIdentity.GetCurrent())
        //  {
        //      LabelUserName.Text = wi.Name;

        //  }

        //  LabelUserName.Text = Request.LogonUserIdentity.Name.ToString();
        ////  LabelUserName.Text = Request.UserHostAddress;


        string[] computer_name = System.Net.Dns.GetHostEntry(Request.ServerVariables["remote_addr"]).HostName.Split(new Char[] { '.' });
        String ecname = System.Environment.MachineName;
        LabelMachineName.Text = computer_name[0].ToString();





        if (TextBoxDate.Text == "")
        {
            TextBoxDate.Text = DateTime.Today.ToString("yyyy/MM/dd");
        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
   
 






        String query = "INSERT INTO SGHUOrder(ProfitCenter,Info,StartDate,Person,Computer,Igenylo,SzamlazottAr) VALUES (@ProfitCenter,@Info,@StartDate,@Person,@Computer,@Igenylo,@SzamlazottAr)";
     

        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {

            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@ProfitCenter", SqlDbType.Int).Value = DropDownListProfitCenter.Text.ToString().Trim();
                command.Parameters.Add("@Info", SqlDbType.NChar).Value = TextBoxInfo.Text.ToString().Trim();
                command.Parameters.Add("@StartDate", SqlDbType.Date).Value = TextBoxDate.Text.ToString().Trim();
                command.Parameters.Add("@Person", SqlDbType.NChar).Value = User.Identity.Name.ToString().Trim();
                command.Parameters.Add("@Computer", SqlDbType.NChar).Value = LabelMachineName.Text.ToString().Trim();
                command.Parameters.Add("@Igenylo", SqlDbType.NChar).Value = TextBoxPerson.Text.ToString().Trim();
                command.Parameters.Add("@SzamlazottAr", SqlDbType.NChar).Value = 0;
                con.Open();
                command.ExecuteNonQuery();
                con.Close();



            }
            SqlDataReader dataReader;
            query = " SELECT OrderID FROM SGHUOrder where Person=@Person ORDER BY OrderID DESC";
            string orderid = "";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@Person", SqlDbType.NChar).Value = User.Identity.Name;
                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
                    switch (dataReader[0].ToString().Length)
                    {

                        case 1:
                            orderid = "000" + dataReader[0].ToString();
                            break;

                        case 2:
                            orderid = "00" + dataReader[0].ToString();
                            break;
                        case 3:
                            orderid = "0" + dataReader[0].ToString();
                            break;
                        case 4:
                            orderid = dataReader[0].ToString();
                            break;

                    }





                }

            }

            con.Close();
            query = "SELECT Signature FROM Users where Username=@Person";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@Person", SqlDbType.NChar).Value = User.Identity.Name;
                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {
        //      string mailBody = dataReader[0].ToString().Trim();




















                    string mailBody = "<html><head></head><body><p>Dear Sir or Madam,</p><p></p><p><strong>Order Number:</strong> SGHU ORDER-" + orderid + "</p><p><strong>Date and Time:</strong>" + TextBoxDate.Text + "</p><p><strong>Profit Center:</strong>" + DropDownListProfitCenter.SelectedItem + "</p><p><strong>Requester:</strong> " + Server.UrlPathEncode(TextBoxPerson.Text.ToString().Trim()) + "  </p><p><strong>Information: </strong></p><p>&nbsp;</p><p>" + TextBoxInfo.Text.ToString().Trim() + "</p><p></p><p>&nbsp;</p><p><strong>The invoice has to contain the relevant SGHU order number.</strong></p>";
                

               

                   

                    string b = WebUtility.HtmlDecode(mailBody);
         

                    b = b.Replace(System.Environment.NewLine, "<br/>");










                    //string mailBody = "<html><head></head><body><p>Dear Sir or Madam,</p><p></p><p><strong>Order Number:</strong> SGHU ORDER-" + orderid + "</p><p><strong>Date and Time:</strong>" + TextBoxDate.Text + "</p><p><strong>Profit Center:</strong>" + DropDownListProfitCenter.SelectedItem + "</p><p><strong>Requester:</strong> " + Server.UrlPathEncode(TextBoxPerson.Text.ToString().Trim()) + "  </p><p><strong>Information: </strong></p><p>&nbsp;</p><p>" + TextBoxInfo.Text.ToString().Trim() + "</p><p>;</p><p>&nbsp;</p><p><strong>The invoice has to contain the relevant SGHU order number.</strong></p>";
                

           
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Adatmentés megtörtént!" + "');", true);

                    string script = "window.onload = function() { SendMail('" + DropDownList1.Text.ToString().Trim() + "','" + b + "','" + "Transport - [SGHU ORDER-" + orderid + "]" + "'); };";
                    this.Page.ClientScript.RegisterStartupScript(GetType(), "SendMail", script, true);


                    ClientScript.RegisterStartupScript(this.GetType(), "client", "window.open('index.aspx');", true);
                    //ClientScript.RegisterStartupScript(this.GetType(), "mailto", "parent.location='mailto:" + DropDownList1.Text.ToString().Trim() + "?cc=SGHU_LOG_transportgroup@bosch.com;SGHU_TransportCost@bosch.com&subject= Transport - [SGHU ORDER-" + orderid + "]  &body= " + mailBody + "'", true);
                }

            }








            //ClientScript.RegisterStartupScript(this.GetType(), "mailto", "parent.location='mailto:" + email + "?subject=" + "Áruátvétel - [SGHU ORDER-" + orderid + "]" + "&body=" + Msg + "'", true);

            //EMailKuld("Áruátvétel - [SGHU ORDER-" + orderid + "]", Msg, to);







        }




    }
    private void CreateMailItem()
    {
  
    }

    public static void EMailKuld(string subject, string body, string to)
    {



        //Outlook.Application oApp = new Outlook.Application();
        //Outlook._MailItem oMailItem = (Outlook._MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
        //oMailItem.To = "supporttools@authorcode.com";
        //// body, bcc etc...
        //oMailItem.Display(true);



        //Outlook.MailItem mailItem = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
        //mailItem.Subject = "This is the test message";
        //mailItem.To = "contactus@authorcode.com";
        //mailItem.CC = "supporttools@authorcode.com";
        //mailItem.Body = "This is the test message";
        //mailItem.Importance = Outlook.OlImportance.olImportanceNormal;
        //mailItem.Display(true );
        //mailItem = null;
        //oApp = null;


        //try
        //{
        //    MailMessage mailMessage = new MailMessage();
        //    mailMessage.From = new MailAddress("external.Jozsef.Kokeny@hu.bosch.com");          
        //    mailMessage.To.Add("external.Jozsef.Kokeny@hu.bosch.com");  
        //    mailMessage.Subject = subject;
        //    mailMessage.Body = body;
        //    mailMessage.IsBodyHtml = true;     
        //    SmtpClient smtpClient = new SmtpClient("rb-smtp-int.bosch.com");
        //    smtpClient.Send(mailMessage);
        //}
        //catch (System.Exception ex)
        //{
        //    string a = ex.Message;
        //}
    }


    protected void btnDOB_Click(object sender, EventArgs e)
    {
        try
        {
            if (TextBoxDate.Text.Trim() != "")
                cdrCalendar.SelectedDate =
                Convert.ToDateTime(TextBoxDate.Text);
        }
        catch
        { }

        cdrCalendar.Visible = true;

    }

    protected void cdrCalendar_SelectionChanged(object sender, EventArgs e)
    {

        TextBoxDate.Text = cdrCalendar.SelectedDate.ToString("yyy.MM.dd");
        cdrCalendar.Visible = false;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        lblDisplay.Visible = false;
        TextBoxInfo.Visible = true;
        
        Button3.Visible = true;

    }
    protected void DropDownList1_TextChanged(object sender, EventArgs e)
    {
        lblDisplay.Visible = false;
        TextBoxInfo.Visible = true;
      
    }
    protected void DropDownListProfitCenter_SelectedIndexChanged(object sender, EventArgs e)
    {
  
    }
    protected void DropDownListProfitCenter_TextChanged(object sender, EventArgs e)
    {
  
    }
    protected void btnSendMail_Click(object sender, EventArgs e)
    {

    }
}
