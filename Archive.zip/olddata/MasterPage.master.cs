﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class MasterPage : System.Web.UI.MasterPage
{
    string[] stringArray = new string[40];
    protected void Page_Load(object sender, EventArgs e)
    {
        string blab = Page.User.Identity.Name.ToString();
        blab = blab.ToLower().Trim();
        switch (blab)
        {
            case "sghucontrollinguser":
                Button1.Visible = true;
                Button2.Visible = true;
                Button5.Visible = true;
                break;
            case "rbhmcontrollinguser":
                Button1.Visible = true;
                Button2.Visible = true;
                Button5.Visible = true;
                break;
            case "mcpcontrollinguser":
                Button1.Visible = true;
                Button2.Visible = true;
                Button5.Visible = true;
                break;
            case "jk89mc":
                Button1.Visible = true;
                Button2.Visible = true;
                Button5.Visible = true;
                break;
            default:
                Button1.Visible = false;
                Button2.Visible = false;
                Button5.Visible = false;
                break;
        }
        if (IsPostBack)
        {
            //for (int i = 0; i < GridView1.Columns.Count; i++)
            //{
            //    stringArray[i] = GridView1.HeaderRow.Cells[i].Text;
            //}
            //foreach (GridViewRow Row in GridView1.Rows)
            //{
            //    if (Row.RowIndex > 0)
            //    {
            //        for (int i = 0; i < GridView1.Columns.Count; i++)
            //        {
            //            Row.Cells[i].Style.Add("BORDER-RIGHT", "#000000 1px solid");
            //        }
            //        Row.Cells[0].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[6].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[9].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[16].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[21].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[25].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[30].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[33].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[34].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //    }
            //    if (Row.RowIndex == 0)
            //    {
            //        Row.Cells[0].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[1].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[2].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[3].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[4].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[5].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[6].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[7].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[8].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[9].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //    }
            //    if (Row.RowIndex < 0)
            //    {
            //        Row.Cells[0].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[1].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[2].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[3].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[4].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[5].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //        Row.Cells[6].Style.Add("BORDER-RIGHT", "#000000 3px solid");
            //    }
            //    if (Row.RowIndex > 1)
            //    {
            //        for (int i = 0; i < GridView1.Columns.Count; i++)
            //        {
            //            Row.Cells[i].CssClass = "nowrap";
            //        }
            //        for (int i = 0; i < GridView1.Columns.Count; i++)
            //        {
            //            Row.Cells[i].BackColor = System.Drawing.Color.FromName("#ffffff");
            //        }
            //        for (int i = 7; i < 10; i++)
            //        {
            //            Row.Cells[i].BackColor = System.Drawing.Color.FromName("#f2dcdb");
            //        }
            //    }
            //    if (Row.RowIndex == 1)
            //    {
            //        for (int i = 0; i < GridView1.Columns.Count; i++)
            //        {
            //            Row.Cells[i].Text = stringArray[i];
            //        }
            //        for (int i = 0; i < 1; i++)
            //        {
            //            Row.Cells[i].BackColor = System.Drawing.Color.FromName("#0000f0");
            //        }
            //        for (int i = 2; i < 9; i++)
            //        {
            //            Row.Cells[i].BackColor = System.Drawing.Color.FromName("#00b0f0");
            //        }
            //        for (int i = 10; i < 11; i++)
            //        {
            //            Row.Cells[i].BackColor = System.Drawing.Color.FromName("#92d050");
            //        }
            //        for (int i = 22; i < 31; i++)
            //        {
            //            Row.Cells[i].BackColor = System.Drawing.Color.FromName("#92d050");
            //        }
            //        for (int i = 31; i < 34; i++)
            //        {
            //            Row.Cells[i].BackColor = System.Drawing.Color.FromName("#fabf8f");
            //        }
            //        Row.BackColor = System.Drawing.Color.FromName("#00B0F0");
            //        Row.HorizontalAlign = HorizontalAlign.Center;
            //        Row.ForeColor = System.Drawing.Color.White;
            //    }
            //    if (Row.RowIndex == 0)
            //    {
            //        Row.BackColor = System.Drawing.Color.FromName("#0070c0");
            //        Row.HorizontalAlign = HorizontalAlign.Center;
            //        Row.ForeColor = System.Drawing.Color.White;
            //        Row.Cells[5].BackColor = System.Drawing.Color.FromName("#00b050");
            //        Row.Cells[6].BackColor = System.Drawing.Color.FromName("#00b050");
            //        Row.Cells[7].BackColor = System.Drawing.Color.FromName("#e26b0a");
            //    }
            //    //if (alluserid.Length != 0)
            //    //{
            //    //    foreach (GridViewRow row in GridView1.Rows)
            //    //    {
            //    //        if (row.RowIndex > 1)
            //    //        {
            //    //            CheckBox chk = row.Cells[27].Controls[0] as CheckBox;
            //    //            if (chk != null && chk.Checked)
            //    //            {
            //    //                row.Visible = false;
            //    //            }
            //    //            else
            //    //            {
            //    //                row.Visible = true;
            //    //            }
            //    //        }
            //    //        row.Cells[27].Visible = false;
            //    //        row.Cells[1].Text = row.Cells[1].Text.ToUpper();
            //    //        row.Cells[2].Text = row.Cells[2].Text.ToUpper();
            //    //    }
            //    //}
            //    //else
            //    //{
            //    //    foreach (GridViewRow row in GridView1.Rows)
            //    //    {
            //    //        row.Cells[27].Visible = true;
            //    //        row.Cells[1].Text = row.Cells[1].Text.ToUpper();
            //    //        row.Cells[2].Text = row.Cells[2].Text.ToUpper();
            //    //    }
            //    //}
            //}
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
        Response.Redirect("~/Login.aspx");
    }
    protected void GridView1_RowCreated(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowIndex == 0)
        //{
        //    e.Row.Cells[0].ColumnSpan = 1;
        //    e.Row.Cells[1].ColumnSpan = 6;
        //    e.Row.Cells[2].ColumnSpan = 3;
        //    e.Row.Cells[3].ColumnSpan = 7;
        //    e.Row.Cells[4].ColumnSpan = 5;
        //    e.Row.Cells[5].ColumnSpan = 4;
        //    e.Row.Cells[6].ColumnSpan = 5;
        //    e.Row.Cells[7].ColumnSpan = 3;
        //    e.Row.Cells[8].ColumnSpan = 2;
        //    //if (alluserid != "")
        //    //{
        //    //    e.Row.Cells[7].ColumnSpan = 2;
        //    //}
        //    //else
        //    //{
        //    //    e.Row.Cells[7].ColumnSpan = 3;
        //    //}
        //    for (int i = 10; i < GridView1.Columns.Count; i++)
        //    {
        //        e.Row.Cells[i].Visible = false;
        //    }
        //}
    }
    protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int index = Convert.ToInt32(e.RowIndex);
        index = Convert.ToInt32(GridView1.Rows[index].Cells[GridView1.Columns.Count - 1].Text.ToString());
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = "update [RBHM_LOG-T].[dbo].[Kamionkezelo] set [torolve]=1 where [RBHM_LOG-T].[dbo].[Kamionkezelo].id=@id";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@id", SqlDbType.Int).Value = index;
                con.Open();
                command.ExecuteNonQuery();
                con.Close();
            }
        }
        GridView1.DataBind();
        Page.Response.Redirect(Page.Request.Url.ToString(), true);
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.Header)
        //{
        //    for (int i = 0; i < GridView1.Columns.Count; i++)
        //    {
        //        stringArray[i] = GridView1.Columns[i].HeaderText;
        //    }
        //}
        //if (e.Row.RowIndex == 0)
        //{
        //    e.Row.Cells[0].Text = "ID";
        //    e.Row.Cells[1].Text = "BEÉRKEZŐ GÉPJÁRMŰ ADATAI";
        //    e.Row.Cells[2].Text = "IDŐPONTOK";
        //    e.Row.Cells[3].Text = "BEJÖVŐ ÁRU ADATAI";
        //    e.Row.Cells[4].Text = "BEJÖVŐ SZÁLLÍTMÁNY AZONOSÍTÓK";
        //    e.Row.Cells[5].Text = "TÁVOZÓ GÉPJÁRMŰ ADATAI";
        //    e.Row.Cells[6].Text = "KIMENŐ SZÁLLÍTMÁNY AZONOSÍTÓK";
        //    e.Row.Cells[7].Text = "EGYÉB ADATOK";
        //    e.Row.Cells[8].Text = "Törlés!";
        //    e.Row.Cells[0].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[1].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[2].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[3].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[4].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[5].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[6].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[7].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[8].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[9].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.BackColor = System.Drawing.Color.FromName("#0070c0");
        //    e.Row.HorizontalAlign = HorizontalAlign.Center;
        //    e.Row.ForeColor = System.Drawing.Color.White;
        //    e.Row.Cells[5].BackColor = System.Drawing.Color.FromName("#00b050");
        //    e.Row.Cells[6].BackColor = System.Drawing.Color.FromName("#00b050");
        //    e.Row.Cells[7].BackColor = System.Drawing.Color.FromName("#e26b0a");
        //}
        //if (e.Row.RowIndex > 0)
        //{
        //    for (int i = 0; i < GridView1.Columns.Count; i++)
        //    {
        //        e.Row.Cells[i].Style.Add("BORDER-RIGHT", "#000000 1px solid");
        //    }
        //    e.Row.Cells[0].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[6].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[9].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[16].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[21].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[25].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[30].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[33].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[34].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //}
        //if (e.Row.RowIndex < 0)
        //{
        //    e.Row.Cells[0].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[1].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[2].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[3].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[4].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[5].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //    e.Row.Cells[6].Style.Add("BORDER-RIGHT", "#000000 3px solid");
        //}
        //if (e.Row.RowIndex > 1)
        //{
        //    for (int i = 0; i < GridView1.Columns.Count; i++)
        //    {
        //        e.Row.Cells[i].CssClass = "nowrap";
        //    }
        //    for (int i = 0; i < GridView1.Columns.Count; i++)
        //    {
        //        e.Row.Cells[i].BackColor = System.Drawing.Color.FromName("#ffffff");
        //    }
        //    for (int i = 7; i < 10; i++)
        //    {
        //        e.Row.Cells[i].BackColor = System.Drawing.Color.FromName("#f2dcdb");
        //    }
        //}
        //if (e.Row.RowIndex == 1)
        //{
        //    for (int i = 0; i < GridView1.Columns.Count; i++)
        //    {
        //        e.Row.Cells[i].Text = stringArray[i];
        //    }
        //    for (int i = 0; i < 1; i++)
        //    {
        //        e.Row.Cells[i].BackColor = System.Drawing.Color.FromName("#0000f0");
        //    }
        //    for (int i = 2; i < 9; i++)
        //    {
        //        e.Row.Cells[i].BackColor = System.Drawing.Color.FromName("#00b0f0");
        //    }
        //    for (int i = 10; i < 11; i++)
        //    {
        //        e.Row.Cells[i].BackColor = System.Drawing.Color.FromName("#92d050");
        //    }
        //    for (int i = 22; i < 31; i++)
        //    {
        //        e.Row.Cells[i].BackColor = System.Drawing.Color.FromName("#92d050");
        //    }
        //    for (int i = 31; i < 34; i++)
        //    {
        //        e.Row.Cells[i].BackColor = System.Drawing.Color.FromName("#fabf8f");
        //    }
        //    e.Row.BackColor = System.Drawing.Color.FromName("#00B0F0");
        //    e.Row.HorizontalAlign = HorizontalAlign.Center;
        //    e.Row.ForeColor = System.Drawing.Color.White;
        //}
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        Response.Redirect("UserCreat.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("OnlineGepjarmuRegisztraciosRendszer.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChangePassword.aspx");
    }
}
