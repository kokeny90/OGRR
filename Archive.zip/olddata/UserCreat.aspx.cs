﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class UserCreat : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.IsAuthenticated)
        {
            string blab = User.Identity.Name.ToString();
            blab = blab.ToLower().Trim();
            switch (blab)
            {
                case "sghucontrollinguser":

                    //   txtUsername.Text = "SGHU";
                    break;
                case "rbhmcontrollinguser":
                    //   txtUsername.Text = "RBHM";
                    break;
                case "mcpcontrollingUser":
                    // txtUsername.Text = "MCP";
                    break;
                case "jk89mc":
                    // txtUsername.Text = "MCP";
                    break;
                default:
                    Response.Redirect("OnlineGepjarmuRegisztraciosRendszer.aspx");
                    ButtonFelhsznalo.Visible = false;
                    ButtonRaktar.Visible = false;
                    LabelNev.Text = "Raktár név";
                    PanelAll.Visible = true;
                    masodiksor.Visible = true;
                    harmadiksor.Visible = true;
                    negyediksor.Visible = true;
                    break;
            }

        }
        else
        {
            FormsAuthentication.SignOut();
            Response.Redirect("~/Login.aspx");
        }
    }
    int userId = 0;
    protected void RegisterUser(object sender, EventArgs e)
    {
        SqlDataReader dataReader;
        string query = "";
        string MAXPortak = "";
        string portaID = "";
        if (LabelFejlec.Text.Trim() != "Porta Módositása")
        {
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("Insert_User"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Username", txtUsername.Text.Trim());
                        cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());
                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                        string blab = User.Identity.Name.ToString().Substring(0, 3);
                        switch (blab)
                        {
                            case "SGH":
                                cmd.Parameters.AddWithValue("@CegID", SqlDbType.Int).Value = 382;
                                break;
                            case "RBH":
                                cmd.Parameters.AddWithValue("@CegID", SqlDbType.Int).Value = DBNull.Value;
                                break;
                            case "MCP":
                                cmd.Parameters.AddWithValue("@CegID", SqlDbType.Int).Value = DBNull.Value;
                                break;
                            default:
                                cmd.Parameters.AddWithValue("@CegID", SqlDbType.Int).Value = DBNull.Value;
                                break;
                        }
                        cmd.Connection = con;
                        con.Open();
                        userId = Convert.ToInt32(cmd.ExecuteScalar());
                        con.Close();
                    }
                }
                string message = string.Empty;
                switch (userId)
                {
                    case -1:
                        message = "Username already exists.\\nPlease choose a different username.";
                        break;
                    case -2:
                        message = "Supplied email address has already been used.";
                        break;
                    default:
                        message = "Registration successful.\\nUser Id: " + userId.ToString();
                        break;
                }
                ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + message + "');", true);
            }

        }
        else
        {
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                query = "SELECT dbo.TPortak.ID FROM dbo.TPortak INNER JOIN dbo.Users ON dbo.TPortak.UserId = dbo.Users.UserId WHERE (dbo.Users.torolve IS NULL OR dbo.Users.torolve = 0) AND (dbo.Users.Username = @USerID) ORDER BY dbo.Users.Username;";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    command.Parameters.Add("@USerID", SqlDbType.NChar).Value = DropDownList2.SelectedValue.ToString();
                    con.Open();
                    dataReader = command.ExecuteReader();


                    if (dataReader.Read())
                    {
                        if (dataReader[0] != DBNull.Value)
                        {
                            portaID = dataReader[0].ToString();
                        }
                    }
                }
                con.Close();

                query = "DELETE FROM [RBHM_LOG-T].[dbo].[KapcsoloCegek] WHERE PortaID=@USerID;";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    command.Parameters.Add("@USerID", SqlDbType.Int).Value = int.Parse(portaID);
                    con.Open();
                    dataReader = command.ExecuteReader();
                    con.Close();
                }
                query = "DELETE FROM [RBHM_LOG-T].[dbo].[KapcsoloMitszallit] WHERE PortaID=@USerID;";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    command.Parameters.Add("@USerID", SqlDbType.Int).Value = int.Parse(portaID);
                    con.Open();
                    dataReader = command.ExecuteReader();
                    con.Close();
                }
                query = "DELETE FROM [RBHM_LOG-T].[dbo].[KapcsoloGepjarmuvek] WHERE PortaID=@USerID;";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    command.Parameters.Add("@USerID", SqlDbType.Int).Value = int.Parse(portaID);
                    con.Open();
                    dataReader = command.ExecuteReader();
                    con.Close();
                }
                query = "DELETE FROM [RBHM_LOG-T].[dbo].[KapcsoloTransportesrs] WHERE PortaID=@USerID;";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    command.Parameters.Add("@USerID", SqlDbType.Int).Value = int.Parse(portaID);
                    con.Open();
                    dataReader = command.ExecuteReader();
                    con.Close();
                }



            }



        }
        ///
        ///PORTAK///
        ///
        if (PanelAll.Visible == true)
        {
            int be1 = 0;
            int be2 = 0;
            MAXPortak = portaID;

            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                if (LabelFejlec.Text.Trim() != "Porta Módositása")
                {
                    query = "INSERT INTO [RBHM_LOG-T].[dbo].[TPortak] ( USerID) VALUES (@USerID)";
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        command.Parameters.Add("@USerID", SqlDbType.Int).Value = int.Parse(userId.ToString());
                        con.Open();
                        dataReader = command.ExecuteReader();
                        con.Close();
                    }

                    query = "SELECT MAX(ID) FROM [dbo].[TPortak]";
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        con.Open();
                        dataReader = command.ExecuteReader();
                    }
                    if (dataReader.Read())
                    {
                        if (dataReader[0] != DBNull.Value)
                        {
                            MAXPortak = dataReader[0].ToString();
                        }
                    }

                    con.Close();
                }
                ///
                /// Lokáció(k):///
                ///
                else
                {
                    MAXPortak = portaID;
                }
                foreach (ListItem item in CheckBoxList1.Items)
                {
                    query = "INSERT INTO [RBHM_LOG-T].[dbo].[KapcsoloCegek] ( PortaID, CegID ) VALUES (@PortaID,@CegID)";
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        if (item.Selected)
                        {
                            command.Parameters.Add("@PortaID", SqlDbType.Int).Value = int.Parse(MAXPortak.ToString());
                            command.Parameters.Add("@CegID", SqlDbType.Int).Value = int.Parse(item.Value);
                            con.Open();
                            dataReader = command.ExecuteReader();
                            con.Close();
                        }
                    }
                }
                ///
                /// Gépjármű(k):///
                ///
                foreach (ListItem item in CheckBoxList2.Items)
                {
                    query = "INSERT INTO [RBHM_LOG-T].[dbo].[KapcsoloGepjarmuvek] ( PortaID, GepjarmuID ) VALUES (@PortaID,@GepjarmuID)";
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        if (item.Selected)
                        {
                            command.Parameters.Add("@PortaID", SqlDbType.Int).Value = int.Parse(MAXPortak.ToString());
                            command.Parameters.Add("@GepjarmuID", SqlDbType.Int).Value = int.Parse(item.Value);
                            con.Open();
                            dataReader = command.ExecuteReader();
                            con.Close();
                        }
                    }
                }
                ////
                //Szállítmányozó(k):
                ////         
                foreach (GridViewRow row in GridView1.Rows)
                {
                    query = "INSERT INTO [RBHM_LOG-T].[dbo].[KapcsoloTransportesrs] ( PortaID, TransportesID, Fővállalkozó, Alvállalkozó ) VALUES (@PortaID,@TransportesID,@Fovallalkozo,@Alvallalkozo)";
                    CheckBox chk = row.Cells[0].FindControl("CheckBox1") as CheckBox;
                    CheckBox chk2 = row.Cells[0].FindControl("CheckBox2") as CheckBox;
                    if ((chk != null && chk.Checked) || (chk2 != null && chk2.Checked))
                    {
                        if (chk.Checked) be1 = 1;
                        if (chk2.Checked) be2 = 1;
                        using (SqlCommand command = new SqlCommand(query, con))
                        {
                            command.Parameters.Add("@PortaID", SqlDbType.Int).Value = int.Parse(MAXPortak.ToString());
                            command.Parameters.Add("@TransportesID", SqlDbType.Int).Value = int.Parse(row.Cells[0].Text);
                            command.Parameters.Add("@Fovallalkozo", SqlDbType.Bit).Value = be1;
                            command.Parameters.Add("@Alvallalkozo", SqlDbType.Bit).Value = be2;
                            con.Open();
                            dataReader = command.ExecuteReader();
                            con.Close();
                        }
                    }
                }
                ///
                /// Mitszallit:///
                ///
                foreach (ListItem item in CheckBoxList3.Items)
                {
                    query = "INSERT INTO [RBHM_LOG-T].[dbo].[KapcsoloMitszallit] ( PortaID, MitszalitID ) VALUES (@PortaID,@MitszalitID)";
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        if (item.Selected)
                        {
                            command.Parameters.Add("@PortaID", SqlDbType.Int).Value = int.Parse(MAXPortak.ToString());
                            command.Parameters.Add("@MitszalitID", SqlDbType.Int).Value = int.Parse(item.Value);
                            con.Open();
                            dataReader = command.ExecuteReader();
                            con.Close();
                        }
                    }
                }
            }
        }
        Page.Response.Redirect(Page.Request.Url.ToString(), true);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = false;
        if (Panel1.Visible == true) Panel1.Visible = false; else Panel1.Visible = true;
    }
    protected void ButtonFelhsznalo_Click(object sender, EventArgs e)
    {
        string blab = User.Identity.Name.ToString();
        blab = blab.ToLower().Trim();
        txtUsername.Enabled = false;
        switch (blab)
        {
            case "sghucontrollinguser":
                txtUsername.Text = "SGHU";
                break;
            case "rbhmcontrollinguser":
                txtUsername.Text = "RBHM";
                break;
            case "mcpcontrollinguser":
                txtUsername.Text = "MCP";
                break;
            default:
                ButtonFelhsznalo.Visible = false;
                ButtonRaktar.Visible = false;
                LabelNev.Text = "Raktár név";
                PanelAll.Visible = true;
                masodiksor.Visible = true;
                harmadiksor.Visible = true;
                negyediksor.Visible = true;
                break;
        }
        SqlDataReader dataReader;
        string query;
        query = "select RIGHT(username,4) from [dbo].[Users] where username LIKE  @bemenoadat order by UserId DESC ;";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@bemenoadat", SqlDbType.VarChar).Value = txtUsername.Text + "%";
                con.Open();
                dataReader = command.ExecuteReader();
            }
            if (dataReader.Read())
            {
                if (dataReader[0] != DBNull.Value)
                {
                    int someInt = int.Parse(dataReader[0].ToString()) + 1;
                    txtUsername.Text = txtUsername.Text.Trim() + DateTime.Now.Year.ToString() + someInt.ToString(new string('0', 4));
                }
            }
            else
            {
                txtUsername.Text = txtUsername.Text.Trim() + DateTime.Now.Year.ToString() + "0001";
            }
        }








        regijelszo.Visible = false;
        Button7.Visible = false;
        PanelAll.Visible = true;
        nulladiksor1.Visible = true;
        nulladiksor2.Visible = true;
        nulladiksor3.Visible = true;
        nulladiksor4.Visible = true;
        txtUsername.Visible = true;
        txtPassword.Visible = true;
        txtConfirmPassword.Visible = true;
        txtEmail.Visible = true;
        gombsor.Visible = true;
        LabelFejlec.Text = "Felhasználó Regisztrációja";
        elsosor.Visible = false;
        LabelNev.Text = "Felhasználó név";
        masodiksor.Visible = false;
        harmadiksor.Visible = false;
        negyediksor.Visible = false;
        otodiksor.Visible = false;
        Button5.Text = "Felhasználó Felvétele";
    }
    protected void ButtonRaktar_Click(object sender, EventArgs e)
    {
        txtUsername.Text = null;

        LabelFejlec.Text = "Porta Regisztrációja:";
        regijelszo.Visible = false;
        nulladiksor1.Visible = true;
        nulladiksor2.Visible = true;
        nulladiksor3.Visible = true;
        nulladiksor4.Visible = true;
        txtUsername.Visible = true;
        txtPassword.Visible = true;
        txtConfirmPassword.Visible = true;
        txtEmail.Visible = true;
        elsosor.Visible = false;
        gombsor.Visible = true;
        LabelNev.Text = "Porta név:";
        PanelAll.Visible = true;
        masodiksor.Visible = true;
        harmadiksor.Visible = true;
        negyediksor.Visible = true;
        otodiksor.Visible = true;
        Button5.Text = "Porta Felvétele:";
        Button7.Visible = false;
    }
    protected void ButtonFelhsznalo0_Click(object sender, EventArgs e)
    {
        LabelFejlec.Text = "Felhasználó Modositása";
        PanelAll.Visible = true;
        gombsor.Visible = false;
        Button7.Visible = true;
        regijelszo.Visible = false;
        nulladiksor1.Visible = false;
        nulladiksor2.Visible = false;
        nulladiksor3.Visible = false;
        nulladiksor4.Visible = false;
        txtUsername.Visible = false;
        txtPassword.Visible = false;
        txtConfirmPassword.Visible = false;
        txtEmail.Visible = false;
        DropDownList2.DataSourceID = "Users";
        elsosor.Visible = true;
        LabelNev.Text = "Felhasználó név";
        masodiksor.Visible = false;
        harmadiksor.Visible = false;
        negyediksor.Visible = false;
        otodiksor.Visible = false;
        Users.FilterExpression = @"Username like 'SGHU%' and not (Username like '%Controlling%') ";
        Button5.Text = "Felhasználó Modositása";
        Button5.CausesValidation = false;
    }
    protected void ButtonRaktar0_Click(object sender, EventArgs e)
    {
        PanelAll.Visible = true;
        gombsor.Visible = false;
        Button7.Visible = true;
        nulladiksor1.Visible = false;
        regijelszo.Visible = false;
        nulladiksor2.Visible = false;
        nulladiksor3.Visible = false;
        nulladiksor4.Visible = false;
        txtUsername.Visible = false;
        txtPassword.Visible = false;
        txtConfirmPassword.Visible = false;
        txtEmail.Visible = false;
        LabelFejlec.Text = "Porta Módositása";
        DropDownList2.DataSourceID = "SqlDataSourceRaktarak";
        DropDownList2.DataValueField = "Username";
        elsosor.Visible = true;
        LabelNev.Text = "Raktár név";
        masodiksor.Visible = false;
        harmadiksor.Visible = false;
        negyediksor.Visible = false;
        otodiksor.Visible = false;
        Users.FilterExpression = @"Username like 'SGHU%' and not (Username like '%Controlling%') ";
        Button5.Text = "Porta Módositása";
        Button5.CausesValidation = false;
 
    }
    protected void ButtonLokacio_Click(object sender, EventArgs e)
    {
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = false;
        SqlDataReader dataReader;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = "INSERT INTO [RBHM_LOG-T].[dbo].[cegek] ( cegnev, orszag, iranyitoszam,varos, cim ) VALUES (@cegnev,@orszag,@iranyitoszam,@varos,@cim)";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                if (TextBoxcegnev.Text.Trim() == null || TextBoxcegnev.Text.Trim() == "") command.Parameters.Add("@cegnev", SqlDbType.Text).Value = DBNull.Value; else command.Parameters.Add("@cegnev", SqlDbType.Text).Value = TextBoxcegnev.Text.Trim();
                command.Parameters.Add("@orszag", SqlDbType.Int).Value = int.Parse(DropDownListOrszag.SelectedIndex.ToString());
                if (TextBoxIranyitoszam.Text.Trim() == null || TextBoxIranyitoszam.Text.Trim() == "") command.Parameters.Add("@iranyitoszam", SqlDbType.Int).Value = DBNull.Value; else command.Parameters.Add("@iranyitoszam", SqlDbType.Int).Value = int.Parse(TextBoxIranyitoszam.Text.Trim());
                if (TextBoxVaros.Text.Trim() == null || TextBoxVaros.Text.Trim() == "") command.Parameters.Add("@varos", SqlDbType.Text).Value = DBNull.Value; else command.Parameters.Add("@varos", SqlDbType.Text).Value = TextBoxVaros.Text.Trim();
                if (TextBoxCim.Text.Trim() == null || TextBoxCim.Text.Trim() == "") command.Parameters.Add("@cim", SqlDbType.Text).Value = DBNull.Value; else command.Parameters.Add("@cim", SqlDbType.Text).Value = TextBoxCim.Text.Trim();
                con.Open();
                dataReader = command.ExecuteReader();
            }
        }
        Panel1.Visible = false;
    }
    protected void ButtonTipus_Click(object sender, EventArgs e)
    {
        SqlDataReader dataReader;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = "INSERT INTO [RBHM_LOG-T].[dbo].[gepjarmuvekcsoportositasa] ( kategoria, gepjarmufajtai ) VALUES (@kategoria,@gepjarmufajtai)";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                if (TextBoxkategoria.Text.Trim() == null || TextBoxkategoria.Text.Trim() == "") command.Parameters.Add("@kategoria", SqlDbType.Text).Value = DBNull.Value; else command.Parameters.Add("@kategoria", SqlDbType.Text).Value = TextBoxkategoria.Text.Trim();
                if (TextBoxgepjarmufajtai.Text.Trim() == null || TextBoxgepjarmufajtai.Text.Trim() == "") command.Parameters.Add("@gepjarmufajtai", SqlDbType.Int).Value = DBNull.Value; else command.Parameters.Add("@gepjarmufajtai", SqlDbType.Text).Value = TextBoxgepjarmufajtai.Text.Trim();
                con.Open();
                dataReader = command.ExecuteReader();
                con.Close();
            }
        }
        CheckBoxList2.DataBind();
        SqlDataSource2.DataBind();
        Panel1.Visible = false;

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = false;
        if (Panel2.Visible == true) Panel2.Visible = false; else Panel2.Visible = true;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {

        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel4.Visible = false;
        if (Panel3.Visible == true) Panel3.Visible = false; else Panel3.Visible = true;
    }
    protected void ButtonMitszallit_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        if (Panel4.Visible == true) Panel4.Visible = false; else Panel4.Visible = true;
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        SqlDataReader dataReader;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = "INSERT INTO [RBHM_LOG-T].[dbo].[mitszallit] ( megnevezes ) VALUES (@megnevezes)";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                if (TextBoxMegnevezes.Text.Trim() == null || TextBoxMegnevezes.Text.Trim() == "") command.Parameters.Add("@megnevezes", SqlDbType.Text).Value = DBNull.Value; else command.Parameters.Add("@megnevezes", SqlDbType.Text).Value = TextBoxMegnevezes.Text.Trim();
                con.Open();
                dataReader = command.ExecuteReader();
                con.Close();
            }
        }
        Panel4.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlDataReader dataReader;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = "INSERT INTO [RBHM_LOG-T].[dbo].[mitszallit] ( megnevezes ) VALUES (@megnevezes)";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                if (TextBoxMegnevezes.Text.Trim() == null || TextBoxMegnevezes.Text.Trim() == "") command.Parameters.Add("@cegnev", SqlDbType.Text).Value = DBNull.Value; else command.Parameters.Add("@cegnev", SqlDbType.Text).Value = TextBoxMegnevezes.Text.Trim();
                dataReader = command.ExecuteReader();
            }
        }
        Panel4.Visible = false;
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

        gombsor.Visible = false;

        string query = "";
        Td1.Visible = true;
        regijelszo.Visible = true;
        nulladiksor2.Visible = true;
        nulladiksor3.Visible = true;
        nulladiksor4.Visible = true;
        txtUsername.Visible = true;
        txtPassword.Visible = true;
        txtConfirmPassword.Visible = true;
        txtEmail.Visible = true;
        if (LabelFejlec.Text == "Porta Módositása")
        {
            PanelAll.Visible = true;
            gombsor.Visible = true;
            elsosor.Visible = true;
            masodiksor.Visible = true;
            harmadiksor.Visible = true;
            negyediksor.Visible = true;
            otodiksor.Visible = true;

            //Lokáció(k):
            query = "SELECT [cegnev] FROM [RBHM_LOG-T].[dbo].[Porta All]  WHERE (Username = @bemenoadat) GROUP BY cegnev";
            using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
            {
                using (DataTable dt = new DataTable())
                {

                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        command.Parameters.Add("@bemenoadat", SqlDbType.VarChar).Value = DropDownList2.Text;
                        con.Open();
                        dt.Load(command.ExecuteReader());
                        con.Close();
                    }
                    CheckBoxList1.DataBind();
                    foreach (DataRow dtRow in dt.Rows)
                    {

                        foreach (ListItem item in CheckBoxList1.Items)
                        {
                            if (item.Text == dtRow[0].ToString())
                            {
                                item.Selected = true;
                            }
                            else if (item.Selected == false)
                            {
                                item.Selected = false;
                            }

                        }


                    }
                }
                //Gépjármű tipusa:
                query = "SELECT [gepjarmufajtai] FROM [RBHM_LOG-T].[dbo].[Porta All]  WHERE (Username = @bemenoadat) GROUP BY gepjarmufajtai";
                using (DataTable dt = new DataTable())
                {

                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        command.Parameters.Add("@bemenoadat", SqlDbType.VarChar).Value = DropDownList2.Text;
                        con.Open();
                        dt.Load(command.ExecuteReader());
                        con.Close();
                    }
                    CheckBoxList2.DataBind();
                    foreach (DataRow dtRow in dt.Rows)
                    {

                        foreach (ListItem item in CheckBoxList2.Items)
                        {
                            if (item.Text == dtRow[0].ToString())
                            {
                                item.Selected = true;
                            }
                            else if (item.Selected == false)
                            {
                                item.Selected = false;
                            }

                        }


                    }
                }
                //Szállítmányozó(k):
                query = "SELECT transporter_name,Fővállalkozó,Alvállalkozó FROM [RBHM_LOG-T].[dbo].[Porta All] WHERE (Username = @bemenoadat) GROUP BY transporter_name, Fővállalkozó, Alvállalkozó";
                using (DataTable dt = new DataTable())
                {

                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        command.Parameters.Add("@bemenoadat", SqlDbType.VarChar).Value = DropDownList2.Text;
                        con.Open();
                        dt.Load(command.ExecuteReader());
                        con.Close();
                    }
                    GridView1.DataBind();
                    foreach (DataRow dtRow in dt.Rows)
                    {
                        foreach (GridViewRow row in GridView1.Rows)
                        {
                            CheckBox chk = row.Cells[1].FindControl("CheckBox1") as CheckBox;
                            CheckBox chk2 = row.Cells[2].FindControl("CheckBox2") as CheckBox;
                            if (row.Cells[1].Text.ToString().Trim() == dtRow[0].ToString().Trim())
                            {
                                if (Convert.ToBoolean(dtRow[1].ToString())) chk.Checked = true; else chk.Checked = false;
                                if (Convert.ToBoolean(dtRow[2].ToString())) chk2.Checked = true; else chk.Checked = false;
                            }
                            else if (chk.Checked == false || chk2.Checked == false)
                            {
                                chk.Checked = false;
                                chk.Checked = false;
                            }


                        }




                    }
                }
                //Mitszállíthat(k):
                query = "SELECT megnevezes FROM [RBHM_LOG-T].[dbo].[Porta All] WHERE (Username = @bemenoadat) GROUP BY megnevezes;";
                using (DataTable dt = new DataTable())
                {
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        command.Parameters.Add("@bemenoadat", SqlDbType.VarChar).Value = DropDownList2.Text;
                        con.Open();
                        dt.Load(command.ExecuteReader());
                        con.Close();
                    }
                    CheckBoxList3.DataBind();
                    foreach (DataRow dtRow in dt.Rows)
                    {

                        foreach (ListItem item in CheckBoxList3.Items)
                        {
                            if (item.Text == dtRow[0].ToString())
                            {
                                item.Selected = true;
                            }
                            else if (item.Selected == false)
                            {
                                item.Selected = false;
                            }

                        }


                    }
                }




            }
        }
        else
        {
            //using (DataTable dt = new DataTable())
            //{
            //    dt = ((DataView)Users.Select(DataSourceSelectArguments.Empty)).Table;
            //    foreach (DataRow dtRow in dt.Rows)
            //    {
            //        if (dtRow[0].ToString() == DropDownList2.Text)
            //        {
            //            foreach (DataColumn dc in dt.Columns)
            //            {
            //                txtUsername.Text = dtRow[1].ToString();
            //                txtPassword.Text = dtRow[2].ToString();
            //                txtConfirmPassword.Text = dtRow[2].ToString();
            //                txtEmail.Text = dtRow[3].ToString();
            //            }
            //        }
            //    }
            //}
        }
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            string query = "update [RBHM_LOG-T].[dbo].[Users] set [torolve]=1 where [RBHM_LOG-T].[dbo].[Users].[Username]=@id";
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@id", SqlDbType.VarChar).Value = DropDownList2.Text;
                con.Open();
                command.ExecuteNonQuery();
                con.Close();
            }
        }
        Page.Response.Redirect(Page.Request.Url.ToString(), true);
    }
    protected void Button3_Click1(object sender, EventArgs e)
    {
        int k = 0;

        foreach (Control cnt in PlaceHolder1.Controls)
        {
            if (cnt is TextBox)
            {
                k = k + 1;
                TextBox actualtextbox = (TextBox)cnt;
                if (actualtextbox.Visible == false)
                {
                    actualtextbox.Visible = true;
                    break;
                }
            }
        }
        foreach (Control cnt in PlaceHolder2.Controls)
        {
            if (cnt is TextBox)
            {
                k = k + 1;
                TextBox actualtextbox = (TextBox)cnt;
                if (actualtextbox.Visible == false)
                {
                    actualtextbox.Visible = true;
                    break;
                }
            }
        }
    }
}