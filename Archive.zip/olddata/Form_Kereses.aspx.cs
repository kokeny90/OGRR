﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Form_Kereses : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
 
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.Text == "")
        {
            Response.Redirect("Form_Kereses.aspx");
        }
        else { 
     
        int a = int.Parse(DropDownList1.Text);
        SqlDataReader dataReader;

        String query = "Select * from SGHUOrder where OrderID=" + a;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand(query, con))
            {

                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {

                    TextBoxOrderNumber.Text = dataReader[0].ToString().Trim();

                    DropDownListProfitCenter.SelectedValue = dataReader[1].ToString().Trim();


                    TextBoxInfo.Text = dataReader[2].ToString();
                    TextBoxDate.Text = dataReader[3].ToString();
                    Person.Text = dataReader[4].ToString();
                    TextBoxComputer.Text = dataReader[5].ToString();
                    TextBoxRequester.Text = dataReader[11].ToString();
                    TextBox8.Text = dataReader[6].ToString();
                    TextBox9.Text = dataReader[7].ToString();
                    TextBox10.Text = dataReader[9].ToString();
                    TextBox11.Text = dataReader[8].ToString();
                    TextBox12.Text = dataReader[10].ToString();

                }

                con.Close();



            }




        }



        }



    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlDataReader dataReader;
        String query = "Update SGHUOrder Set ProfitCenter=@ProfitCenter,Info=@Info,Nyomonkovetesi=@Nyomonkovetesi,Konyvelesi=@Konyvelesi,Szamlaszam=@Szamlaszam,SzamlazottAr=@SzamlazottAr,Olepdf=@Olepdf,Igenylo=@Igenylo WHERE OrderID=@OrderID";
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {

            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.Add("@ProfitCenter", SqlDbType.Int).Value = int.Parse(DropDownListProfitCenter.Text);
                command.Parameters.Add("@Info", SqlDbType.NChar).Value = TextBoxInfo.Text.ToString();

                // command.Parameters.Add("@Computer", SqlDbType.NChar).Value = TextBoxComputer.Text.ToString();
                command.Parameters.Add("@Igenylo", SqlDbType.NChar).Value = TextBoxRequester.Text.ToString().Trim();
                command.Parameters.Add("@OrderID", SqlDbType.NChar).Value = DropDownList1.Text;
                command.Parameters.Add("@Nyomonkovetesi", SqlDbType.NChar).Value = TextBox8.Text;

                if (TextBox9.Text == "")
                {
                    command.Parameters.Add("@Konyvelesi", SqlDbType.Int).Value = 0;
                }
                else
                {
                    command.Parameters.Add("@Konyvelesi", SqlDbType.Int).Value = double.Parse(TextBox9.Text.ToString().Trim());
                }






                command.Parameters.Add("@Szamlaszam", SqlDbType.NChar).Value = TextBox10.Text.ToString().Trim();
                if (TextBox11.Text == "")
                {
                    command.Parameters.Add("@SzamlazottAr", SqlDbType.Decimal).Value = 0;
                }
                else
                {

                    command.Parameters.Add("@SzamlazottAr", SqlDbType.Decimal).Value = decimal.Parse(TextBox11.Text.ToString().Trim());
                }
             
                command.Parameters.Add("@Olepdf", SqlDbType.NChar).Value = TextBox12.Text;
                con.Open();
                command.ExecuteNonQuery();
                con.Close();



            }



        }

        int a = int.Parse(DropDownList1.Text);
        query = "Select * from SGHUOrder where OrderID=" + a;
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            using (SqlCommand command = new SqlCommand(query, con))
            {

                con.Open();
                dataReader = command.ExecuteReader();
                if (dataReader.Read())
                {




                    TextBoxOrderNumber.Text = dataReader[0].ToString().Trim();

                    DropDownListProfitCenter.SelectedValue = dataReader[1].ToString().Trim();


                    TextBoxInfo.Text = dataReader[2].ToString();
                    TextBoxDate.Text = dataReader[3].ToString();
                    Person.Text = dataReader[4].ToString();
                    TextBoxComputer.Text = dataReader[5].ToString();
                    TextBoxRequester.Text = dataReader[11].ToString();
                    TextBox8.Text = dataReader[6].ToString();
                    TextBox9.Text = dataReader[7].ToString();
                    TextBox10.Text = dataReader[9].ToString();
                    TextBox11.Text = dataReader[8].ToString();
                    TextBox12.Text = dataReader[10].ToString();




                }

                con.Close();



            }




        }














    }
    protected void Back_Click(object sender, EventArgs e)
    {
        Response.Redirect("index.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
         using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["RBHM_LOG-TConnectionString"].ConnectionString))
        {
            SqlDataReader dataReader;
        con.Close();
        string query = "SELECT Signature FROM Users where Username=@Person";
        using (SqlCommand command = new SqlCommand(query, con))
        {
            command.Parameters.Add("@Person", SqlDbType.NChar).Value = User.Identity.Name;
            con.Open();
            dataReader = command.ExecuteReader();
            if (dataReader.Read())
            {
                string mailBody = dataReader[0].ToString().Trim();
                mailBody = "Tisztelt Ügyintéző!%0D%0A%0D%0AOrder Number: SGHU ORDER-" + TextBoxOrderNumber.Text + " %0D%0ADate and Time:" + TextBoxDate.Text + "%0D%0AProfit Center: " + DropDownListProfitCenter.SelectedItem + "%0D%0ARequester: " + Server.UrlPathEncode(Person.Text.ToString().Trim()) + "%0D%0AInformation: %0D%0A" + Server.UrlPathEncode(TextBoxInfo.Text.ToString().Trim()) + dataReader[0].ToString().Trim() + "%0D%0A %0D%0A%0D%0AThe invoice has to contain the relevant SGHU order number..%0D%0A%0D%0A";

                ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Adatmentés megtörtént!" + "');", true);
                ClientScript.RegisterStartupScript(this.GetType(), "client", "window.open('index.aspx');", true);
                ClientScript.RegisterStartupScript(this.GetType(), "mailto", "parent.location='mailto:" + DropDownList2.Text.ToString().Trim() + "?cc=SGHU_LOG_transportgroup@bosch.com;SGHUEKAERSupplier@bosch.com&subject= Áruátvétel - [SGHU ORDER-" + TextBoxOrderNumber.Text + "]  &body= " + mailBody + "'", true);                  
             


            }

            }

     

    
         query = "Update SGHUOrder Set ProfitCenter=@ProfitCenter,Info=@Info,Nyomonkovetesi=@Nyomonkovetesi,Konyvelesi=@Konyvelesi,Szamlaszam=@Szamlaszam,SzamlazottAr=@SzamlazottAr,Olepdf=@Olepdf,Igenylo=@Igenylo WHERE OrderID=@OrderID";


         using (SqlCommand command = new SqlCommand(query, con))
         {
             command.Parameters.Add("@ProfitCenter", SqlDbType.Int).Value = int.Parse(DropDownListProfitCenter.Text);
             command.Parameters.Add("@Info", SqlDbType.NChar).Value = TextBoxInfo.Text.ToString();

             // command.Parameters.Add("@Computer", SqlDbType.NChar).Value = TextBoxComputer.Text.ToString();
             command.Parameters.Add("@Igenylo", SqlDbType.NChar).Value = TextBoxRequester.Text.ToString().Trim();
             command.Parameters.Add("@OrderID", SqlDbType.NChar).Value = DropDownList1.Text;
             command.Parameters.Add("@Nyomonkovetesi", SqlDbType.NChar).Value = TextBox8.Text;

             if (TextBox9.Text == "")
             {
                 command.Parameters.Add("@Konyvelesi", SqlDbType.Int).Value = 0;
             }
             else
             {
                 command.Parameters.Add("@Konyvelesi", SqlDbType.Int).Value = double.Parse(TextBox9.Text.ToString().Trim());
             }






             command.Parameters.Add("@Szamlaszam", SqlDbType.NChar).Value = TextBox10.Text.ToString().Trim();
             if (TextBox11.Text == "")
             {
                 command.Parameters.Add("@SzamlazottAr", SqlDbType.Decimal).Value = 0;
             }
             else
             {

                 command.Parameters.Add("@SzamlazottAr", SqlDbType.Decimal).Value = decimal.Parse(TextBox11.Text.ToString().Trim());
             }

             command.Parameters.Add("@Olepdf", SqlDbType.NChar).Value = TextBox12.Text;
             con.Close();
             con.Open();
             command.ExecuteNonQuery();
             con.Close();

         }
        }
    }
    protected void TextBoxRequester_TextChanged(object sender, EventArgs e)
    {

    }
}